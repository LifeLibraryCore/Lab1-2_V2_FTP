package src;//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPClient {
    public UDPClient() {
    }

    public static void main(String[] args) throws IOException {
        int sendPort = 9877;
        int receivePort = 9878;
        DatagramSocket clientSocket = new DatagramSocket(sendPort);
        Thread receiveThread = new Thread(() -> {
            try {
                byte[] receiveData = new byte[1024];
                DatagramSocket receiveSocket = new DatagramSocket(receivePort);

                while(true) {
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    receiveSocket.receive(receivePacket);
                    String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
                    System.out.println("Received message: " + message);
                }
            } catch (IOException var5) {
                var5.printStackTrace();
            }
        });
        receiveThread.start();
        BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

        while(true) {
            while(true) {
                System.out.println("Enter 'send' to send a file or 'receive' to request a file from the server:");
                String command = userInput.readLine();
                if (command.equalsIgnoreCase("send")) {
                    System.out.print("Enter the path of the file to send: ");
                    String filePath = userInput.readLine();
                    File file = new File(filePath);
                    if (!file.exists()) {
                        System.out.println("File not found.");
                    } else {
                        byte[] sendData = "send".getBytes();
                        InetAddress serverAddress = InetAddress.getByName("localhost");
                        DatagramPacket sendCommandPacket = new DatagramPacket(sendData, sendData.length, serverAddress, 9876);
                        clientSocket.send(sendCommandPacket);
                        byte[] fileNameData = file.getName().getBytes();
                        DatagramPacket fileNamePacket = new DatagramPacket(fileNameData, fileNameData.length, serverAddress, 9876);
                        clientSocket.send(fileNamePacket);
                        byte[] fileBytes = new byte[(int)file.length()];
                        FileInputStream fileInputStream = new FileInputStream(file);
                        fileInputStream.read(fileBytes);
                        DatagramPacket filePacket = new DatagramPacket(fileBytes, fileBytes.length, serverAddress, 9876);
                        clientSocket.send(filePacket);
                        System.out.println("File sent to server.");
                    }
                } else if (command.equalsIgnoreCase("receive")) {
                    byte[] sendData = "receive".getBytes();
                    InetAddress serverAddress = InetAddress.getByName("localhost");
                    DatagramPacket sendCommandPacket = new DatagramPacket(sendData, sendData.length, serverAddress, 9876);
                    clientSocket.send(sendCommandPacket);
                    System.out.print("Enter the name of the file to receive from the server: ");
                    String requestedFileName = userInput.readLine();
                    byte[] fileNameData = requestedFileName.getBytes();
                    DatagramPacket fileNamePacket = new DatagramPacket(fileNameData, fileNameData.length, serverAddress, 9876);
                    clientSocket.send(fileNamePacket);
                    byte[] receiveData = new byte[1024];
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    clientSocket.receive(receivePacket);
                    String receivedFileName = "received_" + requestedFileName;
                    FileOutputStream fileOutputStream = new FileOutputStream(receivedFileName);
                    fileOutputStream.write(receivePacket.getData(), 0, receivePacket.getLength());
                    fileOutputStream.close();
                    System.out.println("File received from server and saved as: " + receivedFileName);
                }
            }
        }
    }
}
