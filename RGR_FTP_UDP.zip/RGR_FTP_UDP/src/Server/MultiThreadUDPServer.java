package Server;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

import static Server.Config.*;

public class MultiThreadUDPServer {

    //Список клиентов сервера.
    private static final List<DataClient> clients = new ArrayList<>();
    //База данных пользователей.
    private static final Authorization authorization = new Authorization();
    public static void main(String[] args) {
        //Заполняем базу пользователей.
        //Можно реализовать запись из файла.
        authorization.addUser("user_01", "123");
        authorization.addUser("user_02", "321");
        authorization.addUser("user_03", "abc");

        // Стартуем UPD сервер на порту SERVER_PORT и инициализируем переменную
        // для обработки консольных команд с самого сервера.
        try (DatagramSocket serverSocket = new DatagramSocket(SERVER_PORT);
             BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            //--------------------------------------------------
            // ИНИЦИАЛИЗАЦИЯ ПАРАМЕТРОВ СЕРВЕРА
            //--------------------------------------------------
            //Устанавливает время ожидания запроса.
            serverSocket.setSoTimeout(TIMEOUT);
            //Создаём буфер для запроса.
            byte[] receiveData = new byte[FTP_Package.getByteMaxSize()];
            //Создаём буфер для ответа
            byte[] responseData = new byte[FTP_Package.getByteMaxSize()];
            //Буфер
            byte[] buffer = null;
            //Отправлять пакет.
            boolean sendPackage = true;
            //--------------------------------------------------
            // ЗАПУСК ЦИКЛА ОБРАБОТКИ ЗАПРОСОВ
            //--------------------------------------------------
            System.out.println("[ACTION: Main Thread] Server socket created, command console reader for listen to server commands.");
            // Стартуем цикл при условии что серверный сокет не закрыт.
            while (!serverSocket.isClosed()) {
                // Проверяем поступившие комманды из консоли сервера если такие были.
                if (br.ready()) {
                    System.out.println("[ACTION: Main Thread] Main Server found any messages in channel, let's look at them.");
                    // Если команда - quit то инициализируем закрытие сервера и
                    // выход из цикла раздачии нитей монопоточных серверов.
                    String serverCommand = br.readLine();
                    if (serverCommand.equalsIgnoreCase("quit"))
                    {
                        System.out.println("[ACTION: Main Thread] Main Server initiate exiting...");
                        serverSocket.close();
                        break;
                    }
                }
                //Проверяем, живы ли пользователи:
                if (!clients.isEmpty()) {
                    DataClient dtrem = null;
                    for (DataClient obj : clients) {
                        if (!obj.isLive()) {
                            //Удаляем данные о сессии.
                            System.out.println("[ACTION: Main Thread] Remove session data: "
                                    + obj.getClientAddress() + ":" + obj.getClientPort());
                            //......
                            dtrem = obj;
                            break;
                        }
                    }
                    clients.remove(dtrem);
                }


                //Подготовка получаемого пакета.
                DatagramPacket packet = new DatagramPacket(receiveData, receiveData.length);

                //Ожидание подключения.
                try {
                    serverSocket.receive(packet);
                } catch (SocketTimeoutException event) {
                    System.out.println("[INFO: Main Thread] " + event.getMessage() + ".");
                    continue;
                }

                //Берём адрес и порт клиента из пакета.
                InetAddress clientAddress = packet.getAddress();
                int clientPort = packet.getPort();

                // Проверяем, есть ли клиент в списке.
                boolean isExistUser = false;
                DataClient client = null;
                for (DataClient obj : clients) {
                    if (obj.isThisUser(clientAddress, clientPort)) {//Если есть:
                        System.out.println("[ACTION: Main Thread] Old client connected: "
                                + clientAddress.getHostAddress() + ":" + clientPort);
                        isExistUser = true;
                        client = obj;
                        client.setLive();
                        break;
                    }
                }
                if (!isExistUser) {//Если нет:
                    client = new DataClient(clientAddress, clientPort);
                    clients.add(client);
                    System.out.println("[ACTION: Main Thread] New client connected: "
                            + clientAddress.getHostAddress() + ":" + clientPort);
                }

                //Обработка полученных данных.
                FTP_Package ftpPackage = FTP_Package.toFTP_Package(packet.getData());
                String filename = null;
                System.out.println("[ACTION:"+ clientAddress.getHostAddress() + ":" + clientPort
                        + "] READ from clientDialog message, type - "
                        + ftpPackage.getType());
                //Обработка запроса.
                switch (ftpPackage.getType()) {
                    //--------------------------------------------------
                    // ОПРОС СЕРВЕРА НА СОЕДИНЕНИЕ
                    //--------------------------------------------------
                    case PING:
                        responseData = FTP_Package.toByteArray(
                                new FTP_Package(
                                        FTP_Package.Type.PONG
                                ));
                        break;
                    case PONG:
                        sendPackage = false;
                        break;
                    //--------------------------------------------------
                    // СООБЩЕНИЕ
                    //--------------------------------------------------
                    case MESSAGE:
                        if (!client.isAuthorized()) {//Пользователь не авторизован.
                            System.out.println("[ERROR:" + clientAddress + ":" + clientPort +
                                    "] The client isn't authorized.");
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.NOT_AUTHORIZED
                                    ));
                            break;
                        }
                        buffer = ftpPackage.getBuffer();
                        String message = new String(buffer, 0, buffer.length);
                        System.out.println("[INFO:"+ clientAddress.getHostAddress() + ":" + clientPort
                                + "] Message: " + message);
                        responseData = FTP_Package.toByteArray(
                                new FTP_Package(
                                        FTP_Package.Type.MESSAGE
                                ));
                        break;
                    //--------------------------------------------------
                    // ОШИБКА
                    //--------------------------------------------------
                    case ERROR:
                        buffer = ftpPackage.getBuffer();
                        String error = new String(buffer, 0, buffer.length);
                        System.out.println("[ERROR:"+ clientAddress.getHostAddress() + ":" + clientPort
                                + "] " + error);
                        break;
                    //--------------------------------------------------
                    // ВЫХОД КЛИЕНТА
                    //--------------------------------------------------
                    case EXIT:
                        clients.remove(client);
                        System.out.println("[ACTION:"+ clientAddress.getHostAddress() + ":" + clientPort
                                + "] The user logs out of the system and exit.");
                        responseData = FTP_Package.toByteArray(
                                new FTP_Package(
                                        FTP_Package.Type.EXIT
                                ));
                        break;
                    //--------------------------------------------------
                    // АУТЕНТИФИКАЦИЯ
                    //--------------------------------------------------
                    case LOGIN:
                        //Строка аутентификации, пример "username:password".
                        buffer = ftpPackage.getBuffer();
                        String[] user_par = (new String(buffer, 0, buffer.length)).split(":");
                        client.login(authorization ,user_par[0], user_par[1]);
                        if (client.isAuthorized()) {//Если пользователь есть, а пароль соответствует.
                            System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                                    "] The client is authorized.");
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.AUTHORIZED
                                    ));
                        } else {//Если пользователя нет или пароль не соответствует.
                            System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                                    "] The client isn't authorized.");
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.NOT_AUTHORIZED
                                    ));
                        }
                        break;
                    case LOGOUT:
                        client.logout();
                        System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                                "] The user logs out of the system.");
                        responseData = FTP_Package.toByteArray(
                                new FTP_Package(
                                        FTP_Package.Type.NOT_AUTHORIZED
                                ));
                        break;
                    //--------------------------------------------------
                    // АВТОРИЗОВАН?
                    //--------------------------------------------------
                    case AUTHORIZED:
                        System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                                "] Verification of authorization: " + client.isAuthorized());
                        if (client.isAuthorized()) {//Если пользователь авторизован.
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.AUTHORIZED
                                    ));
                        } else {//Если пользователя не авторизован.
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.NOT_AUTHORIZED
                                    ));
                        }
                        break;
                    //--------------------------------------------------
                    // НАЧАТЬ СКАЧИВАНИЕ ФАЙЛА
                    //--------------------------------------------------
                    case START_DOWNLOADING_FILE:
                        if (!client.isAuthorized()) {//Пользователь не авторизован.
                            System.out.println("[ERROR:" + clientAddress + ":" + clientPort +
                                    "] The client isn't authorized.");
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.NOT_AUTHORIZED
                                    ));
                            break;
                        }
                        //Начало отправки файла.
                        System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                                "] File upload has started .");
                        buffer = ftpPackage.getBuffer();
                        filename = new String(buffer, 0, buffer.length);
                        responseData = client.startUploadFile(filename);
                        if (responseData == null) {
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.END_LOAD_FILE
                                    ));
                        }
                        break;
                    //--------------------------------------------------
                    // СКАЧИВАНИЕ ФАЙЛА
                    //--------------------------------------------------
                    case FILE_DOWNLOAD:
                        if (!client.isAuthorized()) {//Пользователь не авторизован.
                            System.out.println("[ERROR:" + clientAddress + ":" + clientPort +
                                    "] The client isn't authorized.");
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.NOT_AUTHORIZED
                                    ));
                            break;
                        }
                        //Отправка файла.
                        responseData = client.uploadFile(true);
                        if (responseData == null) {
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.ERROR
                                    ));
                        }
                        break;
                    case FILE_DOWNLOAD_OLD:
                        if (!client.isAuthorized()) {//Пользователь не авторизован.
                            System.out.println("[ERROR:" + clientAddress + ":" + clientPort +
                                    "] The client isn't authorized.");
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.NOT_AUTHORIZED
                                    ));
                            break;
                        }
                        //Отправка файла.
                        responseData = client.uploadFile(false);
                        if (responseData == null) {
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.ERROR
                                    ));
                        }
                        break;
                    //--------------------------------------------------
                    // НАЧАТЬ ЗАГРУЗКУ ФАЙЛА
                    //--------------------------------------------------
                    case START_UPLOADING_FILE:
                        if (!client.isAuthorized()) {//Пользователь не авторизован.
                            System.out.println("[ERROR:" + clientAddress + ":" + clientPort +
                                    "] The client isn't authorized.");
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.NOT_AUTHORIZED
                                    ));
                            break;
                        }
                        //Начало отправки файла.
                        System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                                "] File download has started .");
                        //Строка аутентификации, пример "filename:numOfpackages".
                        buffer = ftpPackage.getBuffer();
                        String[] file_par = (new String(buffer, 0, buffer.length)).split(":");
                        System.out.println("[INFO:" + clientAddress + ":" + clientPort +
                                "] File size (byte): " + ftpPackage.getNumOfpackag());
                        responseData = client.startDownloadFile(
                                file_par[0],
                                Long.parseLong(file_par[1]));
                        if (responseData == null) {
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.END_LOAD_FILE
                                    ));
                        }
                        break;
                    //--------------------------------------------------
                    // ЗАГРУЗКА ФАЙЛА
                    //--------------------------------------------------
                    case FILE_UPLOAD:
                        if (!client.isAuthorized()) {//Пользователь не авторизован.
                            System.out.println("[ERROR:" + clientAddress + ":" + clientPort +
                                    "] The client isn't authorized.");
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.NOT_AUTHORIZED
                                    ));
                            break;
                        }
                        //Скачивание файла.
                        responseData = client.downloadFile(ftpPackage.getBuffer(), ftpPackage.getNumOfpackag());
                        if (responseData == null) {
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.ERROR
                                    ));
                        }
                        break;
                    //--------------------------------------------------
                    // ЗАКОНЧИТЬ ПЕРЕДАЧУ ФАЙЛА
                    //--------------------------------------------------
                    case END_LOAD_FILE:
                        if (!client.isAuthorized()) {//Пользователь не авторизован.
                            System.out.println("[ERROR:" + clientAddress + ":" + clientPort +
                                    "] The client isn't authorized.");
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.NOT_AUTHORIZED
                                    ));
                            break;
                        }
                        System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                                "] End of file load.");
                        responseData = client.endLoadFile();
                        if (responseData == null) {
                            responseData = FTP_Package.toByteArray(
                                    new FTP_Package(
                                            FTP_Package.Type.ERROR
                                    ));
                        }
                        break;
                    //--------------------------------------------------
                    // ЗАТЫЧКА
                    //--------------------------------------------------
                    default:
                        responseData = FTP_Package.toByteArray(
                                new FTP_Package(
                                        FTP_Package.Type.ERROR
                                ));
                        break;
                }
                if (sendPackage) {
                    DatagramPacket responsePacket = new DatagramPacket(
                            responseData, responseData.length, clientAddress, clientPort);
                    serverSocket.send(responsePacket);
                } else { sendPackage = true; }


                // Отправка ответа всем клиентам
                /*for (InetAddress client : clients) {
                    if (client == c)

                }*/
            }
        }
        catch (IOException | ClassNotFoundException e) {
            System.out.println("[ACTION: Main Thread] " + e.getMessage());
        }
    }


}