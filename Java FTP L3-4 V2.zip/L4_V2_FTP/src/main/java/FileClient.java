import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;

public class FileClient {
    private static final int CHUNK_SIZE = 1024 * 1024; // 1 MB
    private static final String SERVER_ADDRESS = "127.0.0.1"; // Адрес сервера
    private static final int SERVER_PORT = 8081; // Порт сервера

    private Scanner scanner;

    public FileClient() {
        scanner = new Scanner(System.in);
    }

    public void start() {
        System.out.println("Добро пожаловать в консольный клиент!");
        while (true) {
            System.out.println("Выберите действие:");
            System.out.println("1. Загрузить файл на сервер");
            System.out.println("2. Скачать файл с сервера");
            System.out.println("3. Выйти");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Очистка символа новой строки

            switch (choice) {
                case 1:
                    uploadFile();
                    break;
                case 2:
                    downloadFile();
                    break;
                case 3:
                    System.out.println("До свидания!");
                    return;
                default:
                    System.out.println("Неверный выбор, попробуйте снова.");
            }
        }
    }

    public void uploadFile() {
        System.out.println("Введите путь к файлу для загрузки:");
        String filePath = scanner.nextLine();

        File file = new File(filePath);
        String fileName = file.getName();

        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] buffer = new byte[CHUNK_SIZE];
            int bytesRead;
            int chunkNumber = 0;

            while ((bytesRead = fis.read(buffer)) != -1) {
                // Создание POST-запроса для отправки части файла на сервер
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(new URI("http://" + SERVER_ADDRESS + ":" + SERVER_PORT + "/upload?fileName=" + fileName + "&chunkNumber=" + chunkNumber))
                        .header("Content-Type", "application/octet-stream")
                        .POST(HttpRequest.BodyPublishers.ofByteArray(buffer, 0, bytesRead))
                        .build();

                // Отправка POST-запроса на сервер
                HttpClient client = HttpClient.newHttpClient();
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

                // Проверка ответа от сервера
                if (response.statusCode() != 200) {
                    System.out.println("Ошибка при загрузке файла: " + response.body());
                    return;
                }
                chunkNumber++;
            }
            System.out.println("Файл успешно загружен.");
        } catch (Exception e) {
            System.out.println("Ошибка при загрузке файла.");
            e.printStackTrace();
        }
    }

    public void downloadFile() {
        System.out.println("Введите имя файла для загрузки:");
        String fileName = scanner.nextLine();
        System.out.println("Введите путь для сохранения файла:");
        String savePath = scanner.nextLine();

        File outputFile = new File(savePath);
        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            int chunkNumber = 0;
            boolean moreChunks = true;

            while (moreChunks) {
                // Создание GET-запроса для загрузки части файла с сервера
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(new URI("http://" + SERVER_ADDRESS + ":" + SERVER_PORT + "/download/" + fileName + "/" + chunkNumber))
                        .GET()
                        .build();

                // Отправка GET-запроса на сервер
                HttpClient client = HttpClient.newHttpClient();
                HttpResponse<InputStream> response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());

                // Проверка ответа от сервера
                if (response.statusCode() == 416) { // Chunk out of range
                    moreChunks = false;
                    continue;
                } else if (response.statusCode() != 200) {
                    System.out.println("Ошибка при загрузке файла: " + response.body());
                    return;
                }

                // Чтение данных из ответа и запись в файл
                byte[] buffer = response.body().readAllBytes();
                fos.write(buffer);

                // Проверка, есть ли еще части файла на сервере
                moreChunks = buffer.length == CHUNK_SIZE;
                chunkNumber++;
            }
            System.out.println("Файл успешно загружен.");
        } catch (Exception e) {
            System.out.println("Ошибка при загрузке файла.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        FileClient client = new FileClient();
        client.start();
    }
}
