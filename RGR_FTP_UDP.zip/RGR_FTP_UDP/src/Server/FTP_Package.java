package Server;

import java.io.*;

import static Server.Config.BUFFER_SIZE;

public class FTP_Package implements Serializable {
    //Тип пакета.
    int type = 0;
    //Буфер с данными.
    private byte[] buffer = null;
    //Порядковый номер пакета файла, 0 == не файл.
    private long numOfpackag = 0;


    public enum Type {
        //Проверка подключения:
        PING,
        PONG,
        //Сообщение.
        MESSAGE,
        //Ошибка:
        ERROR,
        //Выход:
        EXIT,
        //Типы управляющие авторизацией:
        LOGIN,// Авторизация. Запрос клиента.
        LOGOUT,
        NOT_AUTHORIZED,// Не автоизован. Ответ сервера.
        AUTHORIZED,// Автоизован. Ответ сервера.
        //Типы управляющие передачей файла:
        SET_DOWNLOAD_OPT, //Установить параметры скачивания. Запрос клиента. Ответ сервера (выполнено).
        SET_UPLOAD_OPT, //Установить параметры загрузки. Запрос клиента. Ответ сервера (выполнено).
        START_DOWNLOADING_FILE, //Начать передачу файла от сервера. Запрос клиента.
        START_UPLOADING_FILE, //Начать передачу файла на сервер. Запрос клиента.
        FILE_DOWNLOAD,// Передача пакета файла от сервера. Ответ сервера.
        FILE_UPLOAD,// Передача пакета файла на сервер. Запрос клиента.
        FILE_DOWNLOAD_OLD,// Передача старого пакета файла от сервера. Ответ сервера.
        FILE_UPLOAD_OLD,// Передача старого пакета файла на сервер. Запрос клиента.
        END_LOAD_FILE //Окончить передачу файла. Ответ сервера.
    }

    //--------------------------------------------------
    // КОНСТРУКТОРЫ ДЛЯ СЕРВЕРА И КЛИЕНТА
    //--------------------------------------------------
    public FTP_Package(
            Type    type
    ) {
        this.type = type.ordinal();
    }
    public FTP_Package(
            Type    type,
            byte[]  buffer,
            long    numOfpackag
    ) {
        if (buffer.length <= BUFFER_SIZE) {
            this.type = type.ordinal();
            this.buffer = buffer;
            this.numOfpackag = numOfpackag;
        } else {
            this.type = Type.ERROR.ordinal();
        }
    }
    //--------------------------------------------------
    // GET
    //--------------------------------------------------
    public Type getType() { return (Type.values())[type]; }
    public byte[] getBuffer() {
        return buffer;
    }
    public long getNumOfpackag() {
        return  numOfpackag;
    }
    public static int getByteMaxSize() {return BUFFER_SIZE + 133; }
    //133 - размер всего класса в байтах за иссключением byffer.
    //--------------------------------------------------
    // СЕРИАЛИЗАЦИЯ И ДЕСЕРИАЛИЗАЦИЯ
    //--------------------------------------------------
    public static byte[] toByteArray(FTP_Package ftpPackage) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(ftpPackage);
        oos.close();
        bos.close();
        return bos.toByteArray();
    }
    public static FTP_Package toFTP_Package(byte[] buffer) throws IOException, ClassNotFoundException {
        ByteArrayInputStream bis = new ByteArrayInputStream(buffer);
        ObjectInputStream ois = new ObjectInputStream(bis);
        ois.close();
        bis.close();
        return (FTP_Package) ois.readObject();
    }
}
