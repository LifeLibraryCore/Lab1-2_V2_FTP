package Server;

public class Config {
    /*  Порты [0, 65535]:
        Системные, 0—1023
        Пользовательские, 1024—49151
        Частные, 49152—65535
 */
    public static final int PORT_MIN_VALUE = 0;
    public static final int PORT_MAX_VALUE = 65535;
    public static final int SERVER_PORT = 4000;
    //Время ожидания ответа
    public static final int TIMEOUT = 1000;
    //Минимальное время жизни данных сессии пользователя на стороне сервера.
    public static final int TIMEOUT_DEL_DATA = 30000;
    public static final int BUFFER_SIZE = 1024;
    public static final String DIRECTORY_WITH_FILES = "files/";
    public static final int MAXIMUM_NUMBER_OF_ATTEMPTS = 5;
}
