package Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import static Server.Config.SERVER_MAX_CHILD_THREADS;
import static Server.Config.SERVER_PORT;

public class MultiThreadServer {
    /*
    Наследование Executor <- ExecutorService <- ScheduledExecutorService
    Интерфейсы Executor, ExecutorService и ScheduledExecutorService - реализуют идею того,
    что вместо того, чтоб создавать новый поток под каждую новую задачу, потоки хранятся в неком “хранилище”,
    и когда поступает новая задача, берется уже существующий поток, а не создается новый.

    Интерфейс Executor — базовый интерфейс, который объявляет один метод void execute(Runnable command)
    — запуск задачи, которая описана в объекте типа Runnable.

    Интерфейс ExecutorService уже содержит методы для управления завершением работы,
    а также методы, которые могут возвращать какой-то результат.

    Метод newFixedThreadPool у класса Executors создаст executorService с фиксированным количеством потоков.
    ExecutorService с фиксированным количеством (n) потоков обладает следующей логикой:
        -Максимум n потоков будут активны для обработки задач.
        -Если передано более n задач, они будут удерживаться в очереди до момента, пока потоки не освободятся.
        -Если в работе одного из потоков произойдет сбой и он завершит свою работу, будет создан новый поток на место сломанного.
        -Любой поток из пула активен до тех пор, пока пул не закрыт.
    */
    protected static ExecutorService executeIt = Executors.newFixedThreadPool(SERVER_MAX_CHILD_THREADS);
    protected static Authorization authorization = new Authorization();

    public static void main(String[] args) {
        //Заполняем базу пользователей.
        //Можно реализовать запись из файла.
        authorization.addUser("user_01", "123");
        authorization.addUser("user_02", "321");
        authorization.addUser("user_03", "abc");

        // Стартуем сервер на порту SERVER_PORT и инициализируем переменную для обработки консольных команд с самого сервера
        try (ServerSocket server = new ServerSocket(SERVER_PORT);
             BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
        {
            System.out.println("[ACTION: Main Thread] Server socket created, command console reader for listen to server commands.");

            // Стартуем цикл при условии что серверный сокет не закрыт.
            while (!server.isClosed())
            {
                // Проверяем поступившие комманды из консоли сервера если такие были.
                if (br.ready()) {
                    System.out.println("[ACTION: Main Thread] Main Server found any messages in channel, let's look at them.");

                    // Если команда - quit то инициализируем закрытие сервера и
                    // выход из цикла раздачии нитей монопоточных серверов.
                    String serverCommand = br.readLine();
                    if (serverCommand.equalsIgnoreCase("quit"))
                    {
                        System.out.println("[ACTION: Main Thread] Main Server initiate exiting...");
                        server.close();
                        break;
                    }
                }
                // Если комманд от сервера нет то становимся в ожидание
                // подключения к сокету общения под именем - "clientDialog" на
                // серверной стороне.
                Socket client = server.accept();

                // После получения запроса на подключение сервер создаёт сокет
                // для общения с клиентом и отправляет его в отдельную нить
                // в Runnable(при необходимости можно создать Callable)
                // монопоточную нить = сервер - Server.MonoThreadClientHandler и тот
                // продолжает общение от лица сервера.
                executeIt.execute(new MonoThreadClientHandler(client, authorization));
                System.out.println("[ACTION: Main Thread] Connection accepted.");
            }

            // закрытие пула нитей после завершения работы всех нитей
            executeIt.shutdown();
        }
        catch (IOException e) {
            System.out.println("[ACTION: Main Thread] " + e.toString());
        }
    }
}