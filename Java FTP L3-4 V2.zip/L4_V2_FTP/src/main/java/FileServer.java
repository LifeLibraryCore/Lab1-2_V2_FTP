import static spark.Spark.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileServer {
    private static final int CHUNK_SIZE = 1024 * 1024; // 1 MB

    public static void main(String[] args) {
        port(8081);

        File uploadDirectory = new File("uploads");
        if (!uploadDirectory.exists()) {
            uploadDirectory.mkdir();
        }

        System.out.println("Server started. Waiting for file uploads...");

        post("/upload", (request, response) -> {
            String fileName = request.queryParams("fileName");
            String chunkNumber = request.queryParams("chunkNumber");

            System.out.println("Received request to upload file chunk:");
            System.out.println("File Name: " + fileName + ", Chunk Number: " + chunkNumber);

            if (fileName == null || chunkNumber == null) {
                halt(400, "Missing fileName or chunkNumber parameter");
            }

            byte[] data;
            try (InputStream input = request.raw().getInputStream()) {
                data = input.readAllBytes();
            }

            if (data.length == 0) {
                halt(400, "Empty file chunk received");
            }

            String filePath = "uploads/" + fileName;
            try (FileOutputStream fos = new FileOutputStream(filePath, true)) {
                fos.write(data);
            } catch (IOException e) {
                halt(500, "Failed to save file chunk");
            }

            return "File chunk uploaded successfully";
        });

        get("/download/:fileName/:chunkNumber", (request, response) -> {
            String fileName = request.params("fileName");
            int chunkNumber = Integer.parseInt(request.params("chunkNumber"));
            String filePath = "uploads/" + fileName;

            if (!Files.exists(Paths.get(filePath))) {
                halt(404, "File not found");
            }

            byte[] buffer = new byte[CHUNK_SIZE];
            try (InputStream inputStream = Files.newInputStream(Paths.get(filePath))) {
                long skipped = inputStream.skip((long) chunkNumber * CHUNK_SIZE);
                if (skipped < (long) chunkNumber * CHUNK_SIZE) {
                    halt(416, "Chunk out of range");
                }
                int bytesRead = inputStream.read(buffer);
                if (bytesRead < 0) {
                    halt(416, "Chunk out of range");
                }

                response.raw().getOutputStream().write(buffer, 0, bytesRead);
                response.raw().getOutputStream().flush();
            }

            return response.raw();
        });

        init();
    }
}
