package Client;

import Server.FTP_Package;

import javax.swing.*;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import static Server.Config.*;

public class FTP_Client extends SwingWorker<Void, Void> {
    private InetAddress inetAddress = null;//Адрес
    private int port = 0; //Порт.

    private static Socket serverDialog = null;
    private OutputStream out = null;
    private InputStream in = null;
    private ObjectOutputStream objOut = null;
    private ObjectInputStream objIn = null;

    private String username = null;
    private String password = null;
    private Type type = null;

    private String uploadPath = null;
    private String filePath = null;

    private String downloadPath = null;
    private String saveDir = null;

    private File file = null;
    private FileOutputStream fileOutput = null;
    private FileInputStream fileInput = null;
    private byte[] buffer = null;
    private long numOfpackages = 0;// Кол-во пакетов.
    private long numOfpackag = 0;// Порядковый номер пакета.

    private String message = null;

    public enum Type {
        NOT_SELECTED,
        UPLOAD,
        DOWNLOAD
    }

    public static class FTPCientException extends Exception {
        public FTPCientException(String message) {
            super(message);
        }

        @Override
        public String toString() {
            return getMessage();
        }
    }
    //--------------------------------------------------
    // КОНСТРУКТОР
    //--------------------------------------------------
    FTP_Client(
            String  ip,
            int     port,
            String  username,
            String  password
    ) throws FTPCientException {
        try {
            inetAddress = InetAddress.getByName(ip);
            System.out.printf("[INFO] ip-address: " + inetAddress.getHostAddress() + "\n");
        } catch (UnknownHostException e) {
            throw new FTPCientException("[ERROR] " + e.getMessage() + "\n");
        }
        if (!setPort(port)) {
            throw new FTPCientException("");
        }
        this.username = username;
        this.password = password;
        type = Type.NOT_SELECTED;
    }
    //--------------------------------------------------
    // ДЛЯ SwingWorker<Void, Void>
    //--------------------------------------------------
    @Override
    protected Void doInBackground() throws Exception {
        if (type == Type.NOT_SELECTED) {
            //Если выбор не сделан.
            message = "[ERROR] The option of interacting with the server is not selected!";
            return null;
        }
        if (!connect()) {
            //Если не удалось установить соединение.
            message = "[ERROR] Connection could not be established!";
            return null;
        }
        if (!Authorization()) {
            //Если не удалось авторизоватся.
            message = "[ERROR] Failed to log in!";
            return null;
        }
        if (type == Type.DOWNLOAD) {//Скачивание файла
            if (!downloadFile()) {
                //Если не удалось скачать файл.
                message = "[ERROR] File download failure!";
            }
            else {
                message = "[ACTION] File has been downloaded successfully!";
            }
        } else {//Загрузка файла
            if (!uploadFile()) {
                //Если не удалось загрузить файл.
                message = "[ERROR] File upload failure!";
            } else {
                message = "[ACTION] File has been uploaded successfully!";
            }
        }
        disconnect();

        return null;
    }
    @Override
    protected void done() {
        if (!isCancelled()) {
            JOptionPane.showMessageDialog(null,
                    message, "Message",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
    //--------------------------------------------------
    // МЕТОДЫ УСТАНОВКИ СОЕДИНЕНИЯ
    //--------------------------------------------------
    private boolean connect() {
        try {
            serverDialog = new Socket(inetAddress, this.port);

            // Инициируем каналы общения в сокете, для клиента.

            // Следует инициализировать сначала канал чтения
            // для избежания блокировки выполнения программы на ожидании заголовка в сокете.
            out = serverDialog.getOutputStream();// Канал записи в сокет.
            in = serverDialog.getInputStream();// Канал чтения из сокета.
            System.out.println("[ACTION:" + serverDialog + "] InputStream created");
            System.out.println("[ACTION:" + serverDialog + "] OutputStream  created");

            //Конвертируем потоки в другой тип.
            objOut = new ObjectOutputStream(out);
            objIn = new ObjectInputStream(in);
            System.out.println("[ACTION:" + serverDialog + "] ObjectInputStream created");
            System.out.println("[ACTION:" + serverDialog + "] ObjectOutputStream  created");
        }
        catch (IOException e)
        {
            System.out.println("[ERROR] " + e.getMessage());
            return false;
        }
        return true;
    }
    private void disconnect() {
        try {
            if (serverDialog == null) {
                return;
            }
            if (serverDialog.isClosed()) {
                return ;
            }
            // Выход
            System.out.println("[ACTION:" + serverDialog + "] Closing connections & channels.");

            //Отправляем пакет для закрытия соединения.
            objOut.writeObject(new FTP_Package(
                    FTP_Package.Type.EXIT
            ));
            // Освобождаем буфер сетевых сообщений.
            objOut.flush();

            // Закрываем каналы сокета./*
            objIn.close();
            objOut.close();
            in.close();
            out.close();

            // Закрываем сокет общения с сервером.
            serverDialog.close();

            System.out.println("[ACTION:" + serverDialog + "] Closing connections & channels - DONE.");
        }
        catch (IOException e)
        {
            System.out.println("[ERROR] " + e.getMessage());
        }
    }
    //--------------------------------------------------
    // МЕТОД АВТОРИЗАЦИИ
    //--------------------------------------------------
    private boolean Authorization() {
        try {
            if (serverDialog == null) {
                return false;
            }
            if (serverDialog.isClosed()) {
                return false;
            }
            //Отправляем пакет для автоизации.
            objOut.writeObject(new FTP_Package(
                    FTP_Package.Type.LOGIN,
                    username, password,
                    null, null, 0, 0
            ));
            // Освобождаем буфер сетевых сообщений.
            objOut.flush();
            //Проверяем результат авторизации.
            FTP_Package ftpPackage = (FTP_Package) objIn.readObject();
            switch (ftpPackage.getType()) {
                case AUTHORIZED:
                    //Пользователь авторизован.
                    System.out.println("[ACTION:" + serverDialog +
                            "] The client is authorized.");
                    return true;
                case NOT_AUTHORIZED:
                    //Пользователь не авторизован.
                    System.out.println("[ACTION:" + serverDialog +
                            "] The client isn't authorized.");
                    return false;
            }
        }
        catch (IOException |ClassNotFoundException e)
        {
            System.out.println("[ERROR] " + e.getMessage());
        }
        return false;
    }
    //--------------------------------------------------
    // МЕТОД СКАЧИВАНИЯ ФАЙЛА
    //--------------------------------------------------
    private boolean downloadFile() {
        try {
            if (serverDialog == null) {
                return false;
            }
            if (serverDialog.isClosed()) {
                return false;
            }
            //--------------------------------------------------
            // ПАРАМЕТРЫ СКАЧИВАНИЯ ФАЙЛА
            //--------------------------------------------------
            //Отправляем серверу пакет о информации с именем файла,
            //который хотим скачать.
            objOut.writeObject(new FTP_Package(
                    FTP_Package.Type.SET_DOWNLOAD_OPT,
                    null, null,
                    downloadPath, null, 0, 0
            ));
            // Освобождаем буфер сетевых сообщений.
            objOut.flush();
            //Проверяем результат запроса.
            FTP_Package ftpPackage = (FTP_Package) objIn.readObject();
            switch (ftpPackage.getType()) {
                case NOT_AUTHORIZED:
                    //Пользователь не авторизован.
                    System.out.println("[ACTION:" + serverDialog +
                            "] The client isn't authorized.");
                    return false;
                case SET_DOWNLOAD_OPT:
                    //Начало загрузки файла.
                    System.out.println("[ACTION:" + serverDialog +
                            "] File download has started .");
                    //Проверка ответа.
                    numOfpackages = ftpPackage.getNumOfpackages();
                    numOfpackag = 0;
                    //Если файл отсутствует на сервере.
                    if (numOfpackages == 0 || ftpPackage.getNumOfpackag() == 0) {
                        System.out.println("[ERROR] The file was not found!");
                        return false;
                    }
                    System.out.println("[ACTION:" + serverDialog +
                            "] File size (byte): " + ftpPackage.getNumOfpackag());
                    break;
            }
            //--------------------------------------------------
            // НАЧАЛО СКАЧИВАНИЯ ФАЙЛА
            //--------------------------------------------------
            //Отправляекм запрос на начало скачивания.
            objOut.writeObject(new FTP_Package(
                    FTP_Package.Type.START_DOWNLOADING_FILE
            ));
            // Освобождаем буфер сетевых сообщений.
            objOut.flush();
            //--------------------------------------------------
            // СОЗДАНИЕ ФАЙЛА
            //--------------------------------------------------
            file = new File(saveDir + "/" + downloadPath);
            fileOutput = new FileOutputStream(file);
            //--------------------------------------------------
            // СКАЧИВАНИЕ ФАЙЛА
            //--------------------------------------------------
            numOfpackag = 0;
            while (numOfpackag < numOfpackages) {
                //Принимаем пакет
                ftpPackage = (FTP_Package) objIn.readObject();
                if (ftpPackage.getType() != FTP_Package.Type.FILE_DOWNLOAD) {
                    return false;
                }
                buffer = ftpPackage.getBuffer();
                numOfpackag = ftpPackage.getNumOfpackag();
                //Записывает в файл.
                fileOutput.write(buffer);
                System.out.println("[ACTION:" + serverDialog +
                        "The package was accept under the number: " +
                        numOfpackag + "/" + numOfpackages);
                setProgress((int) (numOfpackag * 100 / numOfpackages));
                //Ответ (продолжить)
                objOut.writeObject(new FTP_Package(
                        FTP_Package.Type.FILE_DOWNLOAD
                ));
                // Освобождаем буфер сетевых сообщений.
                objOut.flush();
            }
            buffer = null;
            fileOutput = null;
            file = null;
            //Ответ (завершить передачу файла)
            objOut.writeObject(new FTP_Package(
                    FTP_Package.Type.END_FILE_TRANSFER
            ));
            // Освобождаем буфер сетевых сообщений.
            objOut.flush();
            //Принимаем пакет
            ftpPackage = (FTP_Package) objIn.readObject();
            if (ftpPackage.getType() != FTP_Package.Type.END_FILE_TRANSFER) {
                return false;
            }

        }
        catch (IOException |ClassNotFoundException e)
        {
            System.out.println("[ERROR] " + e.getMessage());
            return false;
        }
        return true;
    }
    //--------------------------------------------------
    // МЕТОД ЗАГРУЗКИ ФАЙЛА
    //--------------------------------------------------
    private boolean uploadFile() {
        try {
            if (serverDialog == null) {
                return false;
            }
            if (serverDialog.isClosed()) {
                return false;
            }
            //--------------------------------------------------
            // ПРОВЕРЯЕМ ФАЙЛ НА НАЛИЧИЕ
            //--------------------------------------------------
            System.out.println("[ACTION:" + serverDialog +
                    "] File upload has started .");
            //Установка параметров загрузки файла.
            file = new File(filePath);
            System.out.println("[INFO] Path: " + uploadPath);
            if (file.exists()) {
                //Файл существет.
                fileInput = new FileInputStream(file);
                numOfpackages = (file.length() / BUFFER_SIZE) +
                        ((file.length() % BUFFER_SIZE) > 0 ? 1 : 0);
                System.out.println("[ACTION:" + serverDialog +
                        "] File size (byte): " + file.length());
            } else {
                //Файл отсутствует.
                System.out.println("[ERROR] The file was not found!");
                return false;
            }
            //--------------------------------------------------
            // ПАРАМЕТРЫ ЗАГРУЗКИ ФАЙЛА
            //--------------------------------------------------
            //Отправляем серверу пакет о информации файла,
            //который хотим загрузить.
            //Порядковый номер пакета в пакете-ответе с типом SET_(DOWN/UP)LOAD_OPT
            // изпользуется для передачи длинны файла.
            objOut.writeObject(new FTP_Package(
                    FTP_Package.Type.SET_UPLOAD_OPT,
                    null, null,
                    uploadPath, null, numOfpackages, file.length()
            ));
            // Освобождаем буфер сетевых сообщений.
            objOut.flush();
            //Проверяем результат запроса.
            FTP_Package ftpPackage = (FTP_Package) objIn.readObject();
            switch (ftpPackage.getType()) {
                case NOT_AUTHORIZED:
                    //Пользователь не авторизован.
                    System.out.println("[ACTION:" + serverDialog +
                            "] The client isn't authorized.");
                    return false;
                case SET_UPLOAD_OPT:
                    //Начало загрузки файла.
                    System.out.println("[ACTION:" + serverDialog +
                            "] File upload has started .");
                    break;
            }
            //--------------------------------------------------
            // НАЧАЛО ЗАГРУЗКИ ФАЙЛА
            //--------------------------------------------------
            //Отправляекм запрос на начало загрузки.
            objOut.writeObject(new FTP_Package(
                    FTP_Package.Type.START_UPLOADING_FILE
            ));
            // Освобождаем буфер сетевых сообщений.
            objOut.flush();
            //--------------------------------------------------
            // ЗАГРУЗКА ФАЙЛА
            //--------------------------------------------------
            numOfpackag = 0;
            while (numOfpackag < numOfpackages) {
                buffer = fileInput.readNBytes(BUFFER_SIZE);
                numOfpackag++;
                objOut.writeObject(new FTP_Package(
                        FTP_Package.Type.FILE_UPLOAD,
                        null, null, null,
                        buffer,
                        numOfpackages, numOfpackag
                ));
                System.out.println("[ACTION:" + serverDialog +
                        "The package was sent under the number: " +
                        numOfpackag + "/" + numOfpackages);
                setProgress((int) (numOfpackag * 100 / numOfpackages));
                // Освобождаем буфер сетевых сообщений.
                objOut.flush();
                //Ответ (продолжить)
                ftpPackage = (FTP_Package) objIn.readObject();
                if (ftpPackage.getType() != FTP_Package.Type.FILE_UPLOAD) {
                    return false;
                }
            }
            buffer = null;
            fileInput = null;
            file = null;
            //Ответ (завершить передачу файла)
            objOut.writeObject(new FTP_Package(
                    FTP_Package.Type.END_FILE_TRANSFER
            ));
            // Освобождаем буфер сетевых сообщений.
            objOut.flush();
            //Принимаем пакет
            ftpPackage = (FTP_Package) objIn.readObject();
            if (ftpPackage.getType() != FTP_Package.Type.END_FILE_TRANSFER) {
                return false;
            }
        }
        catch (IOException |ClassNotFoundException e)
        {
            System.out.println("[ERROR] " + e.getMessage());
            return false;
        }
        return true;
    }
    //--------------------------------------------------
    // МЕТОДЫ GET и SET
    //--------------------------------------------------
    int getPort() {
        return port;
    }
    Type getType() {
        return type;
    }
    private boolean setPort(int port) {
        if (port < PORT_MIN_VALUE || port > PORT_MAX_VALUE) {
            System.out.println("[ERROR] The value of the \"port\" variable goes beyond the boundary values!");
            System.out.printf("[INFO] Boundary values of the port variable [%d, %d].\n", PORT_MIN_VALUE, PORT_MAX_VALUE);
            return false;
        }
        this.port = port;
        System.out.println("[INFO] port: " + this.port);
        return true;
    }
    void setUploadParameters(
            String uploadPath,
            String filePath
    ) {
        type = Type.UPLOAD;
        this.uploadPath = uploadPath;
        this.filePath = filePath;
    }
    void setDownloadParameters(
            String downloadPath,
            String saveDir
    ) {
        type = Type.DOWNLOAD;
        this.downloadPath = downloadPath;
        this.saveDir = saveDir;
        System.out.println("Save dir: " + this.saveDir);
        System.out.println("Download path: " + this.downloadPath);
    }
}
/*
L1 V2
Симметричный протокол на основе одиночного TCP-соединения

Л1.	Симметричный протокол на основе одиночного TCP-соединения (симметричный протокол).
Приложения устанавливают одиночное соединение и реализуют двунаправленный сервис
(каждое приложение может выполнять требуемый набор действий);

В2.	Передача и получение файла с противоположного клиента или сервера в виде
последовательностиблоковс двоичными данными в установленном соединении  (FTP-сервер);

Хватит localhost

Две программы, одна с интерфейсом, другая - сервер.
FTP-сервер использует для канала управления TCP-порт 21.
FTP-сервер использует для канала обмена данными TCP-порт 20.
Диапазон свободных портов: 1024…65 535

Определения:
TCP – протокол транспортного уровня, использующий надежный
способ доставки с предварительным установлением соединения и ис-
пользованием средств контроля доставки.

FTP – базовый протокол передачи данных в сети Интернет, позво-
ляющий надежно передавать текстовые и двоичные файлы между раз-
личными файловыми системами. Протокол работает на прикладном
уровне модели OSI.
*/