package Server;

import java.util.HashMap;

//Обёртка класса HashMap для списка пользователей
public class Authorization {
    HashMap<String, String> users = new HashMap<String, String>();

    boolean addUser(String username, String password) {
        if (isExist(username)) {
            //Если существует пользователь с таким именем,
            //то добавление не происходит.
            return false;
        }
        users.put(username, password);
        return true;
    }

    boolean isExist(String username) {
        return users.containsKey(username);
    }

    boolean setPassword(String username, String oldPassword, String newPassword) {
        if (!isExist(username)) {
            //Если такого пользователя не существует.
            return false;
        }
        if (!users.get(username).equals(oldPassword)) {
            //Старый пароль указан не правильно.
            return false;
        }
        users.put(username, newPassword);
        return true;
    }

    boolean isExist(String username, String password) {
        if (!isExist(username)) {
            //Если такого пользователя не существует.
            return false;
        }
        if (users.get(username).equals(password)) {
            //Имя пользователя и пароль указаны верно.
            return true;
        }
        return false;
    }

}
