package Client;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;

public class ClientInterface extends JFrame implements
        PropertyChangeListener {
    //Метки параметров подключения
    private final JLabel labelHost = new JLabel("Host:");
    private final JLabel labelPort = new JLabel("Port:");
    private final JLabel labelUsername = new JLabel("Username:");
    private final JLabel labelPassword = new JLabel("Password:");

    //Поля параметров подключения
    private JTextField fieldHost = new JTextField(40);
    private JTextField fieldPort = new JTextField(5);
    private JTextField fieldUsername = new JTextField(30);
    private JPasswordField fieldPassword = new JPasswordField(30);

    //Режимы Download/Upload
    private JTabbedPane tabbedPane;
    private JPanelDownload panelDownload = new JPanelDownload();
    private JPanelUpload panelUpload = new JPanelUpload();

    //Размер файла
    private JLabel labelFileSize = new JLabel("File size (bytes):");
    private JTextField fieldFileSize = new JTextField(15);

    //Бар прогресса
    private JLabel labelProgress = new JLabel("Progress:");
    private JProgressBar progressBar = new JProgressBar(0, 100);

    private class JPanelDownload extends JPanel {
        private final JLabel labelDownloadPath = new JLabel("Download path:");
        private JTextField fieldDownloadPath = new JTextField(30);
        private JFilePicker filePicker = new JFilePicker(
                "Save file to: ",
                "Browse...");
        private JButton buttonDownload = new JButton("Download");

        JPanelDownload() {
            this.setBorder(new LineBorder(Color.GRAY, 2, false));
            this.setLayout(new GridBagLayout());

            filePicker.setMode(JFilePicker.MODE_SAVE);
            filePicker.getFileChooser().setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            filePicker.setBorder(new LineBorder(Color.GRAY, 2, false));

            //Настройка макета
            GridBagConstraints constraints = new GridBagConstraints();
            constraints.anchor = GridBagConstraints.WEST;
            constraints.insets = new Insets(5, 5, 5, 5);

            //Добаление компонентов
            constraints.gridx = 0;
            constraints.gridy = 0;
            this.add(labelDownloadPath, constraints);

            constraints.gridx = 1;
            constraints.fill = GridBagConstraints.HORIZONTAL;
            constraints.weightx = 1.0;
            this.add(fieldDownloadPath, constraints);

            constraints.gridwidth = 2;
            constraints.gridx = 0;
            constraints.gridy = 2;
            this.add(filePicker , constraints);

            constraints.gridx = 0;
            constraints.gridy = 3;
            constraints.anchor = GridBagConstraints.CENTER;
            this.add(buttonDownload, constraints);
        }

        void addActionListener(ActionListener actionListener) {
            buttonDownload.addActionListener(actionListener);
        }

        String getDownloadPath() {
            return fieldDownloadPath.getText();
        }

        String getDirPath(){
            return filePicker.getSelectedFilePath();
        }

        @Override
        public void setEnabled(boolean val) {
            fieldDownloadPath.setEnabled(val);
            filePicker.setEnabled(val);
            buttonDownload.setEnabled(val);
        }
    }
    private class JPanelUpload extends JPanel {
        private final JLabel labelUploadPath = new JLabel("Upload path:");
        private JTextField fieldUploadPath = new JTextField(30);
        private JFilePicker filePicker = new JFilePicker(
                "Choose a file: ",
                "Browse");
        private JButton buttonUpload = new JButton("Upload");

        JPanelUpload() {
            this.setBorder(new LineBorder(Color.GRAY, 2, false));
            this.setLayout(new GridBagLayout());

            filePicker.setMode(JFilePicker.MODE_OPEN);
            filePicker.setBorder(new LineBorder(Color.GRAY, 2, false));

            //Настройка макета
            GridBagConstraints constraints = new GridBagConstraints();
            constraints.anchor = GridBagConstraints.WEST;
            constraints.insets = new Insets(5, 5, 5, 5);

            //Добаление компонентов
            constraints.gridx = 0;
            constraints.gridy = 0;
            this.add(labelUploadPath, constraints);

            constraints.gridx = 1;
            constraints.fill = GridBagConstraints.HORIZONTAL;
            constraints.weightx = 1.0;
            this.add(fieldUploadPath, constraints);

            constraints.gridwidth = 2;
            constraints.gridx = 0;
            constraints.gridy = 2;
            this.add(filePicker , constraints);

            constraints.gridx = 0;
            constraints.gridy = 3;
            constraints.anchor = GridBagConstraints.CENTER;
            this.add(buttonUpload, constraints);
        }

        void addActionListener(ActionListener actionListener) {
            buttonUpload.addActionListener(actionListener);
        }

        String getUploadPath() {
            return fieldUploadPath.getText();
        }

        String getFilePath(){
            return filePicker.getSelectedFilePath();
        }

        @Override
        public void setEnabled(boolean val) {
            fieldUploadPath.setEnabled(val);
            filePicker.setEnabled(val);
            buttonUpload.setEnabled(val);
        }
    }

    public ClientInterface() {
        super("FTP Client");
        this.setIconImage(new ImageIcon("res/folder-remote-ftp_x32.png").getImage());
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.LIGHT_GRAY);

        panelDownload.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buttonDownloadActionPerformed(e);
            }
        });
        panelUpload.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buttonUploadActionPerformed(e);
            }
        });

        tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Download", panelDownload);
        tabbedPane.addTab("Upload", panelUpload);

        fieldFileSize.setEnabled(false);

        progressBar.setPreferredSize(new Dimension(200, 30));
        progressBar.setStringPainted(true);

        //Настройка макета
        this.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(5, 5, 5, 5);

        //==================================================
        //          Добаление компонентов: подключение
        //==================================================
        constraints.gridx = 0;
        constraints.gridy = 0;
        this.add(labelHost, constraints);

        constraints.gridx = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 1.0;
        this.add(fieldHost, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        this.add(labelPort, constraints);

        constraints.gridx = 1;
        this.add(fieldPort, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        this.add(labelUsername, constraints);

        constraints.gridx = 1;
        this.add(fieldUsername, constraints);

        constraints.gridx = 0;
        constraints.gridy = 3;
        this.add(labelPassword, constraints);

        constraints.gridx = 1;
        this.add(fieldPassword, constraints);

        //==================================================
        //          Добаление компонентов: скачать/загрузить
        //==================================================

        constraints.gridwidth = 2;
        constraints.gridx = 0;
        constraints.gridy = 4;
        constraints.anchor = GridBagConstraints.CENTER;
        this.add(tabbedPane, constraints);
        //this.add(panelDownload, constraints);

        //==================================================
        //          Добаление компонентов: размер файла и прогрес-бар
        //==================================================

        constraints.gridwidth = 1;
        constraints.gridx = 0;
        constraints.gridy = 5;
        constraints.anchor = GridBagConstraints.WEST;
        this.add(labelFileSize, constraints);

        constraints.gridx = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        this.add(fieldFileSize, constraints);

        constraints.gridx = 0;
        constraints.gridy = 6;
        this.add(labelProgress, constraints);

        constraints.gridx = 1;
        this.add(progressBar, constraints);

        this.pack();
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //==================================================
        //          Значения по умолчанию
        //==================================================

        setDefaultValues();
    }

    private void setFileSize(long fileSize) {
        fieldFileSize.setText(String.valueOf(fileSize));
    }

    private void setDefaultValues() {
        fieldHost.setText("127.0.0.1");
        fieldPort.setText("4000");
        fieldUsername.setText("user_01");
        //Для удобства.
        fieldPassword.setText("123");
    }

    private void setInterfaceEnabled(boolean val) {
        fieldHost.setEnabled(val);
        fieldPort.setEnabled(val);
        fieldUsername.setEnabled(val);
        fieldPassword.setEnabled(val);
        tabbedPane.setEnabled(val);
        panelDownload.setEnabled(val);
        panelUpload.setEnabled(val);
    }

    //==================================================
    //Обработать событие нажатия кнопки загрузки
    //==================================================
    private void buttonDownloadActionPerformed(ActionEvent event) {
        String host = fieldHost.getText();
        int port = 0;
        if (!fieldPort.getText().equals("")) {
            port = Integer.parseInt(fieldPort.getText());
        }
        String username = fieldUsername.getText();
        String password = new String(fieldPassword.getPassword());
        String downloadPath = panelDownload.getDownloadPath();
        String saveDir = panelDownload.getDirPath();

        progressBar.setValue(0);
        try {
            FTP_Client ftpClient = new FTP_Client(
                    host,
                    port,
                    username,
                    password
            );
            ftpClient.setDownloadParameters(downloadPath,saveDir);
            ftpClient.addPropertyChangeListener(this);
            ftpClient.execute();
        } catch (FTP_Client.FTPCientException e) {
            System.out.println(e.toString());
        }
    }
    //==================================================
    //Обработать событие нажатия кнопки выгрузки
    //==================================================
    private void buttonUploadActionPerformed(ActionEvent event) {
        String host = fieldHost.getText();
        int port = 0;
        if (!fieldPort.getText().equals("")) {
            port = Integer.parseInt(fieldPort.getText());
        }
        String username = fieldUsername.getText();
        String password = new String(fieldPassword.getPassword());
        String uploadPath = panelUpload.getUploadPath();
        String filePath = panelUpload.getFilePath();

        File uploadFile = new File(filePath);
        setFileSize(uploadFile.length());
        progressBar.setValue(0);

        try {
            FTP_Client ftpClient = new FTP_Client(
                    host,
                    port,
                    username,
                    password
            );
            ftpClient.setUploadParameters(uploadPath,filePath);
            ftpClient.addPropertyChangeListener(this);
            ftpClient.execute();
        } catch (FTP_Client.FTPCientException e) {
            System.out.println(e.toString());
        }
    }
    //==================================================
    //Обновлять состояние индикатора выполнения всякий раз, когда изменяется ход загрузки
    //==================================================
    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if ("progress" == evt.getPropertyName()) {
            int progress = (Integer) evt.getNewValue();
            progressBar.setValue(progress);
        }
    }

    //==================================================
    //          Запуск приложения
    //==================================================
    public static void main(String[] args) {
        try {
            // set look and feel to system dependent
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ClientInterface().setVisible(true);
            }
        });
    }
}
