package Server;

import java.io.*;
import java.net.Socket;

import static Server.Config.BUFFER_SIZE;
import static Server.Config.DIRECTORY_WITH_FILES;

public class MonoThreadClientHandler implements Runnable {

    //Авторизация
    private Authorization authorization = null;
    private boolean isAuthorized = false;
    //Сокет
    private static Socket clientDialog = null;
    private OutputStream out = null;
    private InputStream in = null;
    private ObjectOutputStream objOut = null;
    private ObjectInputStream objIn = null;
    //Обмен пакетами
    private boolean isRunning = true;
    //Файл
    private boolean isTransfer = false;
    private String path = null;
    private File file = null;
    private FileOutputStream fileOutput = null;
    private FileInputStream fileInput = null;
    private byte[] buffer = null;
    private long numOfpackages = 0;// Кол-во пакетов.
    private long numOfpackag = 0;// Порядковый номер пакета.

    public MonoThreadClientHandler(Socket client, Authorization authorization) {
        clientDialog = client;
        synchronized (authorization) {
            this.authorization = authorization;
        }
    }

    @Override
    public void run()
    {
        try
        {
            // Инициируем каналы общения в сокете, для сервера.

            // Следует инициализировать сначала канал чтения
            // для избежания блокировки выполнения программы на ожидании заголовка в сокете.
            out = clientDialog.getOutputStream();// Канал записи в сокет.
            in = clientDialog.getInputStream();// Канал чтения из сокета.
            System.out.println("[ACTION:" + clientDialog + "] InputStream created");
            System.out.println("[ACTION:" + clientDialog + "] OutputStream  created");

            //Конвертируем потоки в другой тип.
            objOut = new ObjectOutputStream(out);
            objIn = new ObjectInputStream(in);
            System.out.println("[ACTION:" + clientDialog + "] ObjectInputStream created");
            System.out.println("[ACTION:" + clientDialog + "] ObjectOutputStream  created");

            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Основная рабочая часть: начало //
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            // Начинаем диалог с подключенным клиентом в цикле, пока сокет не закрыт клиентом.
            // И пока сервер производит обмен пакетами.
            while (!clientDialog.isClosed() && isRunning)
            {
                System.out.println("[ACTION:" + clientDialog + "] Server reading from channel");

                // Серверная нить ждёт в канале чтения (inputstream) получения
                // данных клиента после получения данных считывает их
                FTP_Package ftpPackage = (FTP_Package)objIn.readObject();

                // и выводит в консоль.
                System.out.println("[ACTION:" + clientDialog + "] READ from clientDialog message, type - "
                        + ftpPackage.getType());

                // Инициализация проверки условия продолжения работы с клиентом
                // по этому сокету по типу
                switch (ftpPackage.getType()) {
                    //--------------------------------------------------
                    // АВТОРИЗАЦИЯ
                    //--------------------------------------------------
                    case LOGIN:
                        synchronized (authorization) {
                            isAuthorized = authorization.isExist(
                                    ftpPackage.getLogin(),
                                    ftpPackage.getPassword()
                            );
                        }

                        if (isAuthorized) {//Если пользователь есть, а пароль соответствует.
                            System.out.println("[ACTION:" + clientDialog +
                                    "] The client is authorized.");
                            objOut.writeObject(new FTP_Package(
                                    FTP_Package.Type.AUTHORIZED
                            ));
                            isAuthorized = true;
                        }
                        else {//Если пользователя нет или пароль не соответствует.
                            System.out.println("[ACTION:" + clientDialog +
                                    "] The client isn't authorized.");
                            objOut.writeObject(new FTP_Package(
                                    FTP_Package.Type.NOT_AUTHORIZED
                            ));
                        }
                        break;
                    //--------------------------------------------------
                    // УСТАНОВКА ПАРАМЕТРОВ ПЕРЕДАЧИ ФАЙЛА C СЕРВЕР НА  КЛИЕНТ
                    //--------------------------------------------------
                    case SET_DOWNLOAD_OPT:
                        if (!isAuthorized) {
                            //Не авторизован.
                            System.out.println("[ACTION:" + clientDialog +
                                    "] The client isn't authorized.");
                            objOut.writeObject(new FTP_Package(
                                    FTP_Package.Type.NOT_AUTHORIZED
                            ));
                            break;
                        }
                        //Начало отправки файла.
                        System.out.println("[ACTION:" + clientDialog +
                                "] File upload has started .");
                        //Установка параметров загрузки файла.
                        path = ftpPackage.getPath();
                        file = new File(DIRECTORY_WITH_FILES + path);
                        System.out.println("[INFO] Path: " + path);
                        if (file.exists()) {
                            //Файл существет.
                            fileInput = new FileInputStream(file);
                            numOfpackages = (file.length() / BUFFER_SIZE) +
                                    ((file.length() % BUFFER_SIZE) > 0 ? 1 : 0);
                            System.out.println("[ACTION:" + clientDialog +
                                    "] File size (byte): " + file.length());
                            isTransfer = true;
                        } else {
                            //Файл отсутствует.
                            numOfpackages = 0;
                            System.out.println("[ERROR] The file was not found!");
                        }
                        //Отправляем ответ.
                        //Кол-во пакетов 0 в пакете-ответе с типом SET_(DOWN/UP)LOAD_OPT
                        // означает отсутствие файла.
                        //Порядковый номер пакета в пакете-ответе с типом SET_(DOWN/UP)LOAD_OPT
                        // изпользуется для передачи длинны файла.
                        objOut.writeObject(new FTP_Package(
                                FTP_Package.Type.SET_DOWNLOAD_OPT,
                                null,
                                null,
                                null,
                                null,
                                numOfpackages,
                                file.length()
                        ));
                        break;
                    //--------------------------------------------------
                    // ПЕРЕДАЧА ФАЙЛА С КЛИЕНТА НА СЕРВЕР
                    //--------------------------------------------------
                    case START_DOWNLOADING_FILE:
                        if (!isAuthorized) {
                            //Не авторизован.
                            System.out.println("[ACTION:" + clientDialog +
                                    "] The client isn't authorized.");
                            objOut.writeObject(new FTP_Package(
                                    FTP_Package.Type.NOT_AUTHORIZED
                            ));
                            break;
                        }
                        if (!isTransfer) {
                            //Не начата передача файла.
                            System.out.println("[ACTION:" + clientDialog +
                                    "] File transfer has not started.");
                            objOut.writeObject(new FTP_Package(
                                    FTP_Package.Type.END_FILE_TRANSFER
                            ));
                            break;
                        }
                        System.out.println("[ACTION:" + clientDialog +
                                "File upload has started.");
                        numOfpackag = 0;
                        //Начата передача файла.
                        while (numOfpackag < numOfpackages) {
                            // Освобождаем буфер сетевых сообщений.
                            objOut.flush();
                            //Отправляем пакет
                            buffer = fileInput.readNBytes(BUFFER_SIZE);
                            numOfpackag++;
                            objOut.writeObject(new FTP_Package(
                              FTP_Package.Type.FILE_DOWNLOAD,
                                    null, null, null,
                                    buffer,
                                    numOfpackages, numOfpackag
                            ));
                            System.out.println("[ACTION:" + clientDialog +
                                    "The package was sent under the number: " +
                                    numOfpackag + "/" + numOfpackages);
                            //Ответ (продолжить)
                            ftpPackage = (FTP_Package) objIn.readObject();
                            if (ftpPackage.getType() != FTP_Package.Type.FILE_DOWNLOAD) {
                                break;
                            }
                        }
                        break;
                    //--------------------------------------------------
                    // УСТАНОВКА ПАРАМЕТРОВ ПЕРЕДАЧИ ФАЙЛА C КЛИЕНТА НА  СЕРВЕР
                    //--------------------------------------------------
                    case SET_UPLOAD_OPT:
                        if (!isAuthorized) {
                            //Не авторизован.
                            System.out.println("[ACTION:" + clientDialog +
                                    "] The client isn't authorized.");
                            objOut.writeObject(new FTP_Package(
                                    FTP_Package.Type.NOT_AUTHORIZED
                            ));
                            break;
                        }
                        //Начало отправки файла.
                        System.out.println("[ACTION:" + clientDialog +
                                "] File download has started .");
                        //Установка параметров скачивания файла.
                        isTransfer = true;
                        numOfpackages = ftpPackage.getNumOfpackages();
                        path = ftpPackage.getPath();
                        System.out.println("[INFO] Path: " + DIRECTORY_WITH_FILES + path);
                        file = new File(DIRECTORY_WITH_FILES + path);
                        fileOutput = new FileOutputStream(file);
                        System.out.println("[ACTION:" + clientDialog +
                                "] File size (byte): " + ftpPackage.getNumOfpackag());
                        //Отправляем ответ.
                        objOut.writeObject(new FTP_Package(
                                FTP_Package.Type.SET_UPLOAD_OPT
                        ));
                        break;
                    //--------------------------------------------------
                    // ПЕРЕДАЧА ФАЙЛА C КЛИЕНТА НА  СЕРВЕР
                    //--------------------------------------------------
                    case START_UPLOADING_FILE:
                        if (!isAuthorized) {
                            //Не авторизован.
                            System.out.println("[ACTION:" + clientDialog +
                                    "] The client isn't authorized.");
                            objOut.writeObject(new FTP_Package(
                                    FTP_Package.Type.NOT_AUTHORIZED
                            ));
                            break;
                        }
                        if (!isTransfer) {
                            //Не начата передача файла.
                            System.out.println("[ACTION:" + clientDialog +
                                    "] File transfer has not started.");
                            objOut.writeObject(new FTP_Package(
                                    FTP_Package.Type.END_FILE_TRANSFER
                            ));
                            break;
                        }
                        System.out.println("[ACTION:" + clientDialog +
                                "File download has started.");
                        numOfpackag = 0;
                        //Начата передача файла.
                        while (numOfpackag < numOfpackages) {
                            //Принимаем пакет
                            ftpPackage = (FTP_Package) objIn.readObject();
                            if (ftpPackage.getType() != FTP_Package.Type.FILE_UPLOAD) {
                                break;
                            }
                            buffer = ftpPackage.getBuffer();
                            numOfpackag = ftpPackage.getNumOfpackag();
                            //Записывает в файл.
                            fileOutput.write(buffer);
                            System.out.println("[ACTION:" + clientDialog +
                                    "The package was accept under the number: " +
                                    numOfpackag + "/" + numOfpackages);
                            //Ответ (продолжить)
                            objOut.writeObject(new FTP_Package(
                                    FTP_Package.Type.FILE_UPLOAD
                            ));
                            // Освобождаем буфер сетевых сообщений.
                            objOut.flush();
                        }
                        break;
                    //--------------------------------------------------
                    // ОКОНЧАНИЕ ПЕРЕДАЧА ФАЙЛА
                    //--------------------------------------------------
                    case END_FILE_TRANSFER:
                        numOfpackages = 0;
                        numOfpackag = 0;
                        isTransfer = false;
                        buffer = null;
                        fileInput = null;
                        fileOutput = null;
                        file = null;
                        path = null;
                        objOut.writeObject(new FTP_Package(
                                FTP_Package.Type.END_FILE_TRANSFER
                        ));
                        break;
                    //--------------------------------------------------
                    // Отключение от сервера
                    //--------------------------------------------------
                    case EXIT:
                        isRunning = false;
                        System.out.println("[ACTION:" + clientDialog + "] Client initialize connections suicide...");
                        break;
                    default:
                        break;
                }

                // Освобождаем буфер сетевых сообщений.
                objOut.flush();

                // Возвращаемся в началло для считывания нового сообщения.
            }

            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Основная рабочая часть: конец  //
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            // Если условие выхода - верно выключаем соединения.
            System.out.println("[ACTION:" + clientDialog + "] Client disconnected.");
            System.out.println("[ACTION:" + clientDialog + "] Closing connections & channels.");

            // Закрываем каналы сокета.
            objIn.close();
            objOut.close();
            in.close();
            out.close();

            // Закрываем сокет общения с клиентом в нити моносервера.
            clientDialog.close();

            System.out.println("[ACTION:" + clientDialog + "] Closing connections & channels - DONE.");
        }
        catch (ClassNotFoundException | IOException e)
        {
            System.out.println("[ERROR] " + e.getMessage());
        }
    }
    /*private void sendFile(String path) throws IOException
    {
        int bytes = 0;
        // Open the File where he located in your pc
        File file = new File(path);
        FileInputStream fileInputStream = new FileInputStream(file);

        // Here we send the File to Server/Client
        out.writeLong(file.length());
        // Here we  break file into chunks
        byte[] buffer = new byte[4 * 1024];
        while ((bytes = fileInputStream.read(buffer)) != -1)
        {
            // Send the file to Server Socket
            out.write(buffer, 0, bytes);
            out.flush();
        }
        // close the file here
        fileInputStream.close();
    }
    private void receiveFile(String fileName) throws Exception
    {
        int bytes = 0;
        FileOutputStream fileOutputStream = new FileOutputStream(fileName);

        long size = in.readLong(); // read file size
        byte[] buffer = new byte[4 * 1024];
        while (size > 0
                && (bytes = in.read(
                buffer, 0,
                (int)Math.min(buffer.length, size))
                ) != -1)
        {
            // Here we write the file using write method
            out.write(buffer, 0, bytes);
            size -= bytes; // read upto file size
        }
        // Here we received file
        System.out.println("File is Received");
        fileOutputStream.close();
    }*/
}
