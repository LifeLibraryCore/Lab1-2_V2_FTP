package Server;

import java.io.Serializable;

public class FTP_Package implements Serializable {
    //Тип пакета.
    Type type = null;
    //Регистрация
    private String login = null;
    private String password = null;
    //Файл (часть файла)
    private String path = null;
    private byte[] buffer = null;// Буфер с содержимым файла.
    private long numOfpackages = 0;// Кол-во пакетов.
    private long numOfpackag = 0;// Порядковый номер пакета.
    //Кол-во пакетов 0 в пакете-ответе с типом SET_(DOWN/UP)LOAD_OPT
    // означает отсутствие файла.
    //Порядковый номер пакета в пакете-ответе с типом SET_(DOWN/UP)LOAD_OPT
    // изпользуется для передачи длинны файла.

    public enum Type {
        //Проверка соединения:
        PING,// ping.
        //Типы управляющие авторизацией
        LOGIN,// Авторизация. Запрос клиента.
        NOT_AUTHORIZED,// Не автоизован. Ответ сервера.
        AUTHORIZED,// Автоизован. Ответ сервера.
        //Типы управляющие передачей файла:
        SET_DOWNLOAD_OPT, //Установить параметры скачивания. Запрос клиента. Ответ сервера (выполнено).
        SET_UPLOAD_OPT, //Установить параметры загрузки. Запрос клиента. Ответ сервера (выполнено).
        START_DOWNLOADING_FILE, //Начать передачу файла от сервера. Запрос клиента.
        START_UPLOADING_FILE, //Начать передачу файла на сервер. Запрос клиента.
        FILE_DOWNLOAD,// Передача пакета файла от сервера. Ответ сервера.
        FILE_UPLOAD,// Передача пакета файла на сервер. Запрос клиента.
        END_FILE_TRANSFER, //Окончить передачу файла. Ответ сервера.
        PREVIOUS_FILE_PACKAGE, // Предыдущий пакет файла.
        EXIT //Отключение от сервера. Запрос клиента.
    }
    public FTP_Package(Type type) {
        this.type = type;
    }
    //Конструктор для сервера и клмента.
    public FTP_Package(
            Type    type,
            String  login,
            String  password,
            String  path,
            byte[]  buffer,
            long    numOfpackages,
            long    numOfpackag
    ) {
        this.type = type;
        //Авторизация
        if (type == Type.LOGIN) {
            this.login = login;
            this.password = password;
        }
        //Отправка файла.
        if (type == Type.FILE_DOWNLOAD || type == Type.FILE_UPLOAD) {
            this.buffer = buffer;
            this.numOfpackages = numOfpackages;
            this.numOfpackag = numOfpackag;
        }
        //Начало отправки файла.
        if (type == Type.SET_DOWNLOAD_OPT || type == Type.SET_UPLOAD_OPT) {
            this.path = path;
            this.numOfpackages = numOfpackages;
            this.numOfpackag = numOfpackag;
        }
    }
    public Type getType() {
        return type;
    }
    public String getLogin() {
        return login;
    }
    public String getPassword() {
        return password;
    }
    public String getPath() {
        return path;
    }
    public byte[] getBuffer() {
        return buffer;
    }
    public long getNumOfpackages() {
        return numOfpackages;
    }
    public long getNumOfpackag() {
        return  numOfpackag;
    }
}
