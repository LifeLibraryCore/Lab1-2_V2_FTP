package Client;

import Server.FTP_Package;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.*;

import static Server.Config.*;

public class FTP_Client {
    private InetAddress serverAddress = null;
    private int serverPort = 0;
    private int clientPort = 0;
    private DatagramSocket clientSocket = null;
    //Загрузка или отправка файла:
    private boolean downloadFile = false;
    private boolean uploadFile = false;
    private String fileName = null;
    private File file = null;
    private FileInputStream fileInput = null;
    private FileOutputStream fileOutput = null;
    private byte[] buffer = null;
    private long numOfpackages = 0;
    private long numOfpackag = 0;
    private int numbOfAttempts = 0;
    private boolean packageNotArrive = false;


    //--------------------------------------------------
    // КОНСТРУКТОР
    //--------------------------------------------------
    public FTP_Client(
            InetAddress serverAddress,
            int         serverPort,
            int         clientPort
    ) throws SocketException {
        this.serverAddress = serverAddress;
        this.serverPort = serverPort;
        this.clientPort = clientPort;
        clientSocket = new DatagramSocket(clientPort);
        clientSocket.setSoTimeout(TIMEOUT);
    }

    private DatagramPacket sendDatagramPacket(byte[] data) {
        return new DatagramPacket(
                data,
                data.length,
                serverAddress,
                serverPort);
    }
    //--------------------------------------------------
    // PING
    //--------------------------------------------------
    public boolean ping() throws IOException, ClassNotFoundException {
        if (clientSocket == null) { return false; }
        //Запрос на аутентификацию.
        FTP_Package ftpPackage = new FTP_Package(
                FTP_Package.Type.PING
        );
        byte[] data = FTP_Package.toByteArray(ftpPackage);
        DatagramPacket sendPacket = sendDatagramPacket(data);
        clientSocket.send(sendPacket);
        //Ответ сервера.
        data = new byte[FTP_Package.getByteMaxSize()];
        DatagramPacket packet = new DatagramPacket(data, data.length);
        try {
            clientSocket.receive(packet);
        } catch (SocketTimeoutException event) {
            System.out.println("[INFO: Main Thread] Ping: " + event.getMessage() + ".");
            return false;
        }
        //Обработка ответа сервера.
        ftpPackage = FTP_Package.toFTP_Package(packet.getData());
        return true;
    }
    //--------------------------------------------------
    // АУТЕНТИФИКАЦИЯ
    //--------------------------------------------------
    public boolean login(String username, String password) throws IOException, ClassNotFoundException {
        if (clientSocket == null) { return false; }
        //Запрос на аутентификацию.
        FTP_Package ftpPackage = new FTP_Package(
                FTP_Package.Type.LOGIN,
                (username + ":" + password).getBytes(),
                0
        );
        byte[] data = FTP_Package.toByteArray(ftpPackage);
        DatagramPacket sendPacket = sendDatagramPacket(data);
        clientSocket.send(sendPacket);
        //Ответ сервера.
        data = new byte[FTP_Package.getByteMaxSize()];
        DatagramPacket packet = new DatagramPacket(data, data.length);
        try {
            clientSocket.receive(packet);
        } catch (SocketTimeoutException event) {
            System.out.println("[INFO: Main Thread] Login: " + event.getMessage() + ".");
            return false;
        }
        //Обработка ответа сервера.
        ftpPackage = FTP_Package.toFTP_Package(packet.getData());
        if (ftpPackage.getType() != FTP_Package.Type.AUTHORIZED) { return false; }
        return true;
    }
    public boolean logout() throws IOException, ClassNotFoundException {
        if (clientSocket == null) { return false; }
        //Запрос на аутентификацию.
        FTP_Package ftpPackage = new FTP_Package(
                FTP_Package.Type.LOGOUT
        );
        byte[] data = FTP_Package.toByteArray(ftpPackage);
        DatagramPacket sendPacket = sendDatagramPacket(data);
        clientSocket.send(sendPacket);
        //Ответ сервера.
        data = new byte[FTP_Package.getByteMaxSize()];
        DatagramPacket packet = new DatagramPacket(data, data.length);
        try {
            clientSocket.receive(packet);
        } catch (SocketTimeoutException event) {
            System.out.println("[INFO: Main Thread] Logout: " + event.getMessage() + ".");
            return false;
        }
        //Обработка ответа сервера.
        ftpPackage = FTP_Package.toFTP_Package(packet.getData());
        if (ftpPackage.getType() != FTP_Package.Type.NOT_AUTHORIZED) { return false; }
        return true;
    }
    public boolean isAuthorized() throws IOException, ClassNotFoundException {
        if (clientSocket == null) { return false; }
        //Запрос "пользователь в системе".
        FTP_Package ftpPackage = new FTP_Package(
                FTP_Package.Type.AUTHORIZED
        );
        byte[] data = FTP_Package.toByteArray(ftpPackage);
        DatagramPacket sendPacket = sendDatagramPacket(data);
        clientSocket.send(sendPacket);
        //Ответ сервера.
        data = new byte[FTP_Package.getByteMaxSize()];
        DatagramPacket packet = new DatagramPacket(data, data.length);
        try {
            clientSocket.receive(packet);
        } catch (SocketTimeoutException event) {
            System.out.println("[INFO: Main Thread] IsAuthorized: " + event.getMessage() + ".");
            return false;
        }
        //Обработка ответа сервера.
        ftpPackage = FTP_Package.toFTP_Package(packet.getData());
        if (ftpPackage.getType() != FTP_Package.Type.AUTHORIZED) { return false; }
        return true;
    }
    //--------------------------------------------------
    // СООБЩЕНИЕ
    //--------------------------------------------------
    public boolean sendMessage(String message) throws IOException, ClassNotFoundException {
        if (clientSocket == null) { return false; }
        //Запрос "отправка сообщения".
        FTP_Package ftpPackage = new FTP_Package(
                FTP_Package.Type.MESSAGE,
                message.getBytes(),
                0
        );
        if (ftpPackage.getBuffer() == null) { return false; }
        byte[] data = FTP_Package.toByteArray(ftpPackage);
        DatagramPacket sendPacket = sendDatagramPacket(data);
        clientSocket.send(sendPacket);
        //Ответ сервера.
        data = new byte[FTP_Package.getByteMaxSize()];
        DatagramPacket packet = new DatagramPacket(data, data.length);
        try {
            clientSocket.receive(packet);
        } catch (SocketTimeoutException event) {
            System.out.println("[INFO: Main Thread] SendMessage: " + event.getMessage() + ".");
            return false;
        }
        //Обработка ответа сервера.
        ftpPackage = FTP_Package.toFTP_Package(packet.getData());
        if (ftpPackage.getType() != FTP_Package.Type.MESSAGE) { return false; }
        return true;
    }
    //--------------------------------------------------
    // ВЫХОД
    //--------------------------------------------------
    public boolean exit() throws IOException, ClassNotFoundException {
        if (clientSocket == null) { return false; }
        //Запрос "разрыв соединения".
        FTP_Package ftpPackage = new FTP_Package(
                FTP_Package.Type.EXIT
        );
        byte[] data = FTP_Package.toByteArray(ftpPackage);
        DatagramPacket sendPacket = sendDatagramPacket(data);
        clientSocket.send(sendPacket);
        //Ответ сервера.
        data = new byte[FTP_Package.getByteMaxSize()];
        DatagramPacket packet = new DatagramPacket(data, data.length);
        try {
            clientSocket.receive(packet);
        } catch (SocketTimeoutException event) {
            System.out.println("[INFO: Main Thread] Disconnect: " + event.getMessage() + ".");
            return false;
        }
        //Обработка ответа сервера.
        ftpPackage = FTP_Package.toFTP_Package(packet.getData());
        if (ftpPackage.getType() != FTP_Package.Type.EXIT) { return false; }
        clientSocket.close();
        clientSocket = null;
        return true;
    }
    //--------------------------------------------------
    // СКАЧИВАНИЕ ФАЙЛА
    //--------------------------------------------------
    public boolean downloadFile(
            String          fileName,
            String          saveDir,
            JProgressBar    progressBar
    ) throws IOException, ClassNotFoundException {
        if (clientSocket == null) {
            return false;
        }
        //Если идёт загрузка или отправка файла, то:
        if (uploadFile || downloadFile) {
            return false;
        }
        this.fileName = fileName;
        downloadFile = true;
        System.out.println("[ACTION] File download has started .");
        //Запрос "начать скачивание файла".
        FTP_Package ftpPackage = new FTP_Package(
                FTP_Package.Type.START_DOWNLOADING_FILE,
                this.fileName.getBytes(),
                0
        );
        byte[] data = FTP_Package.toByteArray(ftpPackage);
        DatagramPacket sendPacket = sendDatagramPacket(data);
        clientSocket.send(sendPacket);
        //Ответ сервера.
        data = new byte[FTP_Package.getByteMaxSize()];
        DatagramPacket packet = new DatagramPacket(data, data.length);
        try {
            clientSocket.receive(packet);
        } catch (SocketTimeoutException event) {
            System.out.println("[INFO: Main Thread] DownloadFile: " + event.getMessage());
            return false;
        }
        //Обработка ответа сервера.
        ftpPackage = FTP_Package.toFTP_Package(packet.getData());
        if (ftpPackage.getType() == FTP_Package.Type.END_LOAD_FILE) {
            System.out.println("[INFO: Main Thread] DownloadFile: The file was not found!");
            return false;
        } else if (ftpPackage.getType() != FTP_Package.Type.START_UPLOADING_FILE) {
            System.out.println("[ERROR: Main Thread] DownloadFile.");
            return false;
        }
        buffer = ftpPackage.getBuffer();
        numOfpackages = Long.parseLong(new String(buffer, 0, buffer.length));
        System.out.println("[INFO] File size (byte): " + ftpPackage.getNumOfpackag());
        numOfpackag = 1;
        //--------------------------------------------------
        // СОЗДАНИЕ ФАЙЛА
        //--------------------------------------------------
        file = new File(saveDir + "/" + fileName);
        fileOutput = new FileOutputStream(file);
        //--------------------------------------------------
        // ПЕРЕДАЧА ФАЙЛА
        //--------------------------------------------------
        numOfpackag = 0;
        packageNotArrive = false;
        buffer = new byte[BUFFER_SIZE];
        while (numOfpackag < numOfpackages) {
            if (packageNotArrive) {
                //Запрос "запросить пакет с не пришедшей частью файла".
                ftpPackage = new FTP_Package(
                        FTP_Package.Type.FILE_DOWNLOAD_OLD
                );
            } else {
                //Запрос "запросить пакет с частью файла".
                numOfpackag++;
                ftpPackage = new FTP_Package(
                        FTP_Package.Type.FILE_DOWNLOAD
                );
            }
            data = FTP_Package.toByteArray(ftpPackage);
            sendPacket = sendDatagramPacket(data);
            clientSocket.send(sendPacket);
            //Ответ сервера.
            data = new byte[FTP_Package.getByteMaxSize()];
            packet = new DatagramPacket(data, data.length);
            try {
                clientSocket.receive(packet);
                packageNotArrive = false;
            } catch (SocketTimeoutException event) {
                if (numbOfAttempts < MAXIMUM_NUMBER_OF_ATTEMPTS) {
                    System.out.println("[INFO: Main Thread] Repeat the attempt.");
                    packageNotArrive = true;
                    numbOfAttempts++;
                } else {
                    System.out.println("[INFO: Main Thread] DownloadFile: " + event.getMessage() + ".");
                    numbOfAttempts = 0;
                    return false;
                }
            }
            //Обработка ответа сервера.
            ftpPackage = FTP_Package.toFTP_Package(packet.getData());
            if (ftpPackage.getType() != FTP_Package.Type.FILE_UPLOAD) {
                System.out.println("[INFO: Main Thread] DownloadFile: error!");
                return false;
            }
            if (numOfpackag != ftpPackage.getNumOfpackag()) {
                packageNotArrive = true;
            } else {
                numOfpackag = ftpPackage.getNumOfpackag();
                System.out.println("[ACTION] The package was accept under the number: " +
                        numOfpackag + "/" + numOfpackages);
                if (progressBar != null) {
                    progressBar.setValue((int)(numOfpackag * 100 / numOfpackages));
                }
                buffer = ftpPackage.getBuffer();
                fileOutput.write(buffer);
            }
        }
        //--------------------------------------------------
        // ПЕРЕДАЧА ФАЙЛА
        //--------------------------------------------------
        //Запрос "закончить скачивание файла".
        ftpPackage = new FTP_Package(
                FTP_Package.Type.END_LOAD_FILE
        );
        data = FTP_Package.toByteArray(ftpPackage);
        sendPacket = sendDatagramPacket(data);
        clientSocket.send(sendPacket);
        //Ответ сервера.
        data = new byte[FTP_Package.getByteMaxSize()];
        packet = new DatagramPacket(data, data.length);
        try {
            clientSocket.receive(packet);
        } catch (SocketTimeoutException event) {
            System.out.println("[INFO: Main Thread] DownloadFile: " + event.getMessage() + ".");
            return false;
        }
        //Обработка ответа сервера.
        ftpPackage = FTP_Package.toFTP_Package(packet.getData());
        if (ftpPackage.getType() != FTP_Package.Type.END_LOAD_FILE) {
            return false;
        }
        System.out.println("[ACTION] End of file download.");
        numOfpackages = 0;
        numOfpackag = 0;
        fileOutput.close();
        fileOutput = null;
        file = null;
        this.fileName = null;
        buffer = null;
        downloadFile = false;
        return true;
    }
    //--------------------------------------------------
    // ЗАГРУЗКА ФАЙЛА
    //--------------------------------------------------
    public boolean uploadFile(
            String          fileName,
            String          filePath,
            JProgressBar    progressBar
    ) throws IOException, ClassNotFoundException {
        if (clientSocket == null) {
            return false;
        }
        //Если идёт загрузка или отправка файла, то:
        if (uploadFile || downloadFile) {
            return false;
        }
        this.fileName = fileName;
        uploadFile = true;
        //--------------------------------------------------
        // ПРОВЕРЯЕМ ФАЙЛ НА НАЛИЧИЕ
        //--------------------------------------------------
        System.out.println("[ACTION] File upload has started .");
        //Установка параметров загрузки файла.
        file = new File(filePath);
        System.out.println("[INFO] Path: " + filePath);
        if (file.exists()) {
            //Файл существет.
            fileInput = new FileInputStream(file);
            numOfpackages = (file.length() / BUFFER_SIZE) +
                    ((file.length() % BUFFER_SIZE) > 0 ? 1 : 0);
            System.out.println("[ACTION] File size (byte): " + file.length());
        } else {
            //Файл отсутствует.
            System.out.println("[ERROR] The file was not found!");
            return false;
        }

        System.out.println("[ACTION] File download has started .");
        //Запрос "начать загрузку файла".
        FTP_Package ftpPackage = new FTP_Package(
                FTP_Package.Type.START_UPLOADING_FILE,
                (this.fileName + ":" + numOfpackages).getBytes(),
                file.length()//Размер файла
        );
        byte[] data = FTP_Package.toByteArray(ftpPackage);
        DatagramPacket sendPacket = sendDatagramPacket(data);
        clientSocket.send(sendPacket);
        //Ответ сервера.
        data = new byte[FTP_Package.getByteMaxSize()];
        DatagramPacket packet = new DatagramPacket(data, data.length);
        try {
            clientSocket.receive(packet);
        } catch (SocketTimeoutException event) {
            System.out.println("[INFO: Main Thread] UploadFile: " + event.getMessage());
            return false;
        }
        //Обработка ответа сервера.
        ftpPackage = FTP_Package.toFTP_Package(packet.getData());
        if (ftpPackage.getType() == FTP_Package.Type.END_LOAD_FILE) {
            System.out.println("[INFO: Main Thread] UploadFile: The file was not found!");
            return false;
        } else if (ftpPackage.getType() != FTP_Package.Type.START_DOWNLOADING_FILE) {
            System.out.println("[ERROR: Main Thread] UploadFile.");
            return false;
        }
        //--------------------------------------------------
        // ПЕРЕДАЧА ФАЙЛА
        //--------------------------------------------------
        numOfpackag = 0;
        packageNotArrive = false;
        buffer = new byte[BUFFER_SIZE];
        while (numOfpackag < numOfpackages) {
            if (!packageNotArrive) {
                numOfpackag++;
                buffer = fileInput.readNBytes(BUFFER_SIZE);
            }
            //Запрос "отправить пакет с частью файла".
            ftpPackage = new FTP_Package(
                    FTP_Package.Type.FILE_UPLOAD,
                    buffer,
                    numOfpackag
            );
            data = FTP_Package.toByteArray(ftpPackage);
            sendPacket = sendDatagramPacket(data);
            clientSocket.send(sendPacket);
            System.out.println("[ACTION] The package was sent under the number: " +
                    numOfpackag + "/" + numOfpackages);
            if (progressBar != null) {
                progressBar.setValue((int)(numOfpackag * 100 / numOfpackages));
            }
            //Ответ сервера.
            data = new byte[FTP_Package.getByteMaxSize()];
            packet = new DatagramPacket(data, data.length);
            try {
                clientSocket.receive(packet);
                packageNotArrive = false;
            } catch (SocketTimeoutException event) {
                if (numbOfAttempts < MAXIMUM_NUMBER_OF_ATTEMPTS) {
                    System.out.println("[INFO: Main Thread] Repeat the attempt.");
                    packageNotArrive = true;
                    numbOfAttempts++;
                } else {
                    System.out.println("[INFO: Main Thread] UploadFile: " + event.getMessage() + ".");
                    numbOfAttempts = 0;
                    return false;
                }
            }
            //Обработка ответа сервера.
            ftpPackage = FTP_Package.toFTP_Package(packet.getData());
            if (ftpPackage.getType() == FTP_Package.Type.FILE_DOWNLOAD) {
                packageNotArrive = false;
            } else if (ftpPackage.getType() == FTP_Package.Type.FILE_DOWNLOAD_OLD) {
                packageNotArrive = true;
            } else {
                System.out.println("[INFO: Main Thread] DownloadFile: error!");
                return false;
            }
        }
        //--------------------------------------------------
        // ПЕРЕДАЧА ФАЙЛА
        //--------------------------------------------------
        //Запрос "закончить отправку файла".
        ftpPackage = new FTP_Package(
                FTP_Package.Type.END_LOAD_FILE
        );
        data = FTP_Package.toByteArray(ftpPackage);
        sendPacket = sendDatagramPacket(data);
        clientSocket.send(sendPacket);
        //Ответ сервера.
        data = new byte[FTP_Package.getByteMaxSize()];
        packet = new DatagramPacket(data, data.length);
        try {
            clientSocket.receive(packet);
        } catch (SocketTimeoutException event) {
            System.out.println("[INFO: Main Thread] UploadFile: " + event.getMessage() + ".");
            return false;
        }
        //Обработка ответа сервера.
        ftpPackage = FTP_Package.toFTP_Package(packet.getData());
        if (ftpPackage.getType() != FTP_Package.Type.END_LOAD_FILE) {
            return false;
        }
        System.out.println("[ACTION] End of file upload.");
        numOfpackages = 0;
        numOfpackag = 0;
        fileInput.close();
        fileInput = null;
        file = null;
        this.fileName = null;
        buffer = null;
        uploadFile = false;
        return true;
    }
    //--------------------------------------------------
    // СКАЧИВАНИЕ И ОТПРАВКА ФАЙЛА (ОБНУЛЕНИЕ)
    //--------------------------------------------------
    public boolean resetLoadFile() throws IOException, ClassNotFoundException {
        if (clientSocket == null) {
            return false;
        }
        numOfpackages = 0;
        numOfpackag = 0;
        if (fileInput != null) {
            fileInput.close();
            fileInput = null;
        }
        if (fileOutput != null) {
            fileOutput.close();
            fileOutput = null;
        }
        file = null;
        fileName = null;
        buffer = null;
        downloadFile = false;
        uploadFile = false;

        byte[] data = new byte[FTP_Package.getByteMaxSize()];
        DatagramPacket packet = new DatagramPacket(data, data.length);
        try {
            clientSocket.receive(packet);
        } catch (SocketTimeoutException event) {
            System.out.println("[INFO: Main Thread] ResetLoadFile: " + event.getMessage() + ".");
            return false;
        }
        //Обработка ответа сервера.
        FTP_Package ftpPackage = FTP_Package.toFTP_Package(packet.getData());
        if (ftpPackage.getType() != FTP_Package.Type.END_LOAD_FILE) {
            return false;
        }
        return true;
    }
}