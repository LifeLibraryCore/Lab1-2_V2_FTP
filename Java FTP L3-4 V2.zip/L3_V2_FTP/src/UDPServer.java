package src;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPServer {
    public UDPServer() {
    }

    public static void main(String[] args) throws IOException {
        DatagramSocket serverSocket = new DatagramSocket(9876);
        byte[] receiveData = new byte[1024];

        while(true) {
            while(true) {
                while(true) {
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    serverSocket.receive(receivePacket);
                    String command = new String(receivePacket.getData(), 0, receivePacket.getLength());
                    InetAddress clientAddress = receivePacket.getAddress();
                    int clientPort = receivePacket.getPort();
                    String errorMessage;
                    byte[] fileBytesToSend;
                    DatagramPacket sendPacket;
                    PrintStream var10000;
                    String var10001;
                    switch (command.toLowerCase()) {
                        case "send":
                            serverSocket.receive(receivePacket);
                            String fileName = new String(receivePacket.getData(), 0, receivePacket.getLength());
                            serverSocket.receive(receivePacket);
                            byte[] fileBytes = receivePacket.getData();
                            FileOutputStream fileOutputStream = new FileOutputStream("received_" + fileName);

                            try {
                                fileOutputStream.write(fileBytes);
                            } catch (Throwable var19) {
                                try {
                                    fileOutputStream.close();
                                } catch (Throwable var17) {
                                    var19.addSuppressed(var17);
                                }

                                throw var19;
                            }

                            fileOutputStream.close();
                            var10000 = System.out;
                            var10001 = String.valueOf(clientAddress);
                            var10000.println("File received from client at " + var10001 + ":" + clientPort);
                            break;
                        case "receive":
                            serverSocket.receive(receivePacket);
                            String requestedFileName = new String(receivePacket.getData(), 0, receivePacket.getLength());
                            File file = new File(requestedFileName);
                            if (file.exists() && !file.isDirectory()) {
                                FileInputStream fileInputStream = new FileInputStream(file);

                                try {
                                    fileBytesToSend = new byte[(int)file.length()];
                                    fileInputStream.read(fileBytesToSend);
                                    sendPacket = new DatagramPacket(fileBytesToSend, fileBytesToSend.length, clientAddress, clientPort);
                                    serverSocket.send(sendPacket);
                                } catch (Throwable var18) {
                                    try {
                                        fileInputStream.close();
                                    } catch (Throwable var16) {
                                        var18.addSuppressed(var16);
                                    }

                                    throw var18;
                                }

                                fileInputStream.close();
                                var10000 = System.out;
                                var10001 = String.valueOf(clientAddress);
                                var10000.println("File sent to client at " + var10001 + ":" + clientPort);
                                break;
                            }

                            errorMessage = "File '" + requestedFileName + "' not found on the server.";
                            fileBytesToSend = errorMessage.getBytes();
                            sendPacket = new DatagramPacket(fileBytesToSend, fileBytesToSend.length, clientAddress, clientPort);
                            serverSocket.send(sendPacket);
                            System.out.println("Error: " + errorMessage);
                            break;
                        default:
                            errorMessage = "Unknown command: " + command;
                            fileBytesToSend = errorMessage.getBytes();
                            sendPacket = new DatagramPacket(fileBytesToSend, fileBytesToSend.length, clientAddress, clientPort);
                            serverSocket.send(sendPacket);
                            System.out.println("Error: " + errorMessage);
                    }
                }
            }
        }
    }
}
