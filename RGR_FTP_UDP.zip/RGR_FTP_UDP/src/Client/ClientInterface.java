package Client;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

public class ClientInterface extends JFrame implements
        PropertyChangeListener {
    //Метки параметров подключения
    private final JLabel labelHost = new JLabel("Host:");
    private final JLabel labelPort = new JLabel("Port:");
    private final JLabel labelClientPort = new JLabel("Client port:");
    private final JLabel labelUsername = new JLabel("Username:");
    private final JLabel labelPassword = new JLabel("Password:");

    //Поля параметров подключения
    private JTextField fieldHost = new JTextField(40);
    private JTextField fieldPort = new JTextField(5);
    private JTextField fieldClientPort = new JTextField(5);
    private JTextField fieldUsername = new JTextField(30);
    private JPasswordField fieldPassword = new JPasswordField(30);

    private JCheckBox checkBoxConnetction = new JCheckBox("Connection");
    private JCheckBox checkBoxLogin = new JCheckBox("Login");

    private JButton buttonConnect = new JButton("Connect");
    private JButton buttonDisconnect = new JButton("Disconnect");

    private JButton buttonLogin = new JButton("Login");
    private JButton buttonLogout = new JButton("Logout");

    //Режимы Download/Upload
    private JTabbedPane tabbedPane;
    private JPanelDownload panelDownload = new JPanelDownload();
    private JPanelUpload panelUpload = new JPanelUpload();

    //Размер файла
    private JLabel labelFileSize = new JLabel("File size (bytes):");
    private JTextField fieldFileSize = new JTextField(15);

    //Бар прогресса
    private JLabel labelProgress = new JLabel("Progress:");
    private JProgressBar progressBar = new JProgressBar(0, 100);

    FTP_Client ftpClient = null;

    private class JPanelDownload extends JPanel {
        private final JLabel labelDownloadPath = new JLabel("Download path:");
        private JTextField fieldDownloadPath = new JTextField(30);
        private JFilePicker filePicker = new JFilePicker(
                "Save file to: ",
                "Browse...");
        private JButton buttonDownload = new JButton("Download");

        JPanelDownload() {
            this.setBorder(new LineBorder(Color.GRAY, 2, false));
            this.setLayout(new GridBagLayout());

            filePicker.setMode(JFilePicker.MODE_SAVE);
            filePicker.getFileChooser().setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            filePicker.setBorder(new LineBorder(Color.GRAY, 2, false));

            //Настройка макета
            GridBagConstraints constraints = new GridBagConstraints();
            constraints.anchor = GridBagConstraints.WEST;
            constraints.insets = new Insets(5, 5, 5, 5);

            //Добаление компонентов
            constraints.gridx = 0;
            constraints.gridy = 0;
            this.add(labelDownloadPath, constraints);

            constraints.gridx = 1;
            constraints.fill = GridBagConstraints.HORIZONTAL;
            constraints.weightx = 1.0;
            this.add(fieldDownloadPath, constraints);

            constraints.gridwidth = 2;
            constraints.gridx = 0;
            constraints.gridy = 2;
            this.add(filePicker , constraints);

            constraints.gridx = 0;
            constraints.gridy = 3;
            constraints.anchor = GridBagConstraints.CENTER;
            this.add(buttonDownload, constraints);
        }

        void addActionListener(ActionListener actionListener) {
            buttonDownload.addActionListener(actionListener);
        }

        String getDownloadPath() {
            return fieldDownloadPath.getText();
        }

        String getDirPath(){
            return filePicker.getSelectedFilePath();
        }

        @Override
        public void setEnabled(boolean val) {
            fieldDownloadPath.setEnabled(val);
            filePicker.setEnabled(val);
            buttonDownload.setEnabled(val);
        }
    }
    private class JPanelUpload extends JPanel {
        private final JLabel labelUploadPath = new JLabel("Upload path:");
        private JTextField fieldUploadPath = new JTextField(30);
        private JFilePicker filePicker = new JFilePicker(
                "Choose a file: ",
                "Browse");
        private JButton buttonUpload = new JButton("Upload");

        JPanelUpload() {
            this.setBorder(new LineBorder(Color.GRAY, 2, false));
            this.setLayout(new GridBagLayout());

            filePicker.setMode(JFilePicker.MODE_OPEN);
            filePicker.setBorder(new LineBorder(Color.GRAY, 2, false));

            //Настройка макета
            GridBagConstraints constraints = new GridBagConstraints();
            constraints.anchor = GridBagConstraints.WEST;
            constraints.insets = new Insets(5, 5, 5, 5);

            //Добаление компонентов
            constraints.gridx = 0;
            constraints.gridy = 0;
            this.add(labelUploadPath, constraints);

            constraints.gridx = 1;
            constraints.fill = GridBagConstraints.HORIZONTAL;
            constraints.weightx = 1.0;
            this.add(fieldUploadPath, constraints);

            constraints.gridwidth = 2;
            constraints.gridx = 0;
            constraints.gridy = 2;
            this.add(filePicker , constraints);

            constraints.gridx = 0;
            constraints.gridy = 3;
            constraints.anchor = GridBagConstraints.CENTER;
            this.add(buttonUpload, constraints);
        }

        void addActionListener(ActionListener actionListener) {
            buttonUpload.addActionListener(actionListener);
        }

        String getUploadPath() {
            return fieldUploadPath.getText();
        }

        String getFilePath(){
            return filePicker.getSelectedFilePath();
        }

        @Override
        public void setEnabled(boolean val) {
            fieldUploadPath.setEnabled(val);
            filePicker.setEnabled(val);
            buttonUpload.setEnabled(val);
        }
    }

    public ClientInterface() {
        super("FTP Client");
        this.setIconImage(new ImageIcon("res/folder-remote-ftp_x32.png").getImage());
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.LIGHT_GRAY);

        panelDownload.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buttonDownloadActionPerformed(e);
            }
        });
        panelUpload.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buttonUploadActionPerformed(e);
            }
        });
        buttonConnect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                //Проверяет, есть ли по этому соединению сервер.
                try {
                    if((ftpClient = new FTP_Client(
                            InetAddress.getByName(getHost()),
                            getPort(),
                            getClientPort()
                    )).ping()) {
                        checkBoxConnetction.setSelected(true);
                        buttonConnect.setEnabled(false);
                        buttonDisconnect.setEnabled(true);
                        buttonLogin.setEnabled(true);
                    }
                } catch (IOException | ClassNotFoundException e) {
                    setDefaultStatus();
                    System.out.println("[ERROR] " + e.getMessage());
                }
            }
        });
        buttonDisconnect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                //Принудительно удаляем данные о нашей сессии на сервере.
                if (ftpClient == null) { return; }
                try {
                    if(ftpClient.exit()) {
                        checkBoxConnetction.setSelected(false);
                        buttonConnect.setEnabled(true);
                        buttonDisconnect.setEnabled(false);
                        buttonLogin.setEnabled(false);
                        buttonLogout.setEnabled(false);
                        panelDownload.setEnabled(false);
                        panelUpload.setEnabled(false);
                    }
                } catch (IOException | ClassNotFoundException e) {
                    setDefaultStatus();
                    System.out.println("[ERROR] " + e.getMessage());
                }
                ftpClient = null;
            }
        });
        buttonLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                //Авторизуемся.
                if (ftpClient == null) { return; }
                try {
                    if(ftpClient.login(getUsername(), getPassword())) {
                        checkBoxLogin.setSelected(true);
                        buttonLogin.setEnabled(false);
                        buttonLogout.setEnabled(true);
                        panelDownload.setEnabled(true);
                        panelUpload.setEnabled(true);
                    }
                } catch (IOException | ClassNotFoundException e) {
                    setDefaultStatus();
                    System.out.println("[ERROR] " + e.getMessage());
                }
            }
        });
        buttonLogout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (ftpClient == null) { return; }
                try {
                    if(ftpClient.logout()) {
                        checkBoxLogin.setSelected(false);
                        buttonLogin.setEnabled(true);
                        buttonLogout.setEnabled(false);
                        panelDownload.setEnabled(false);
                        panelUpload.setEnabled(false);
                    }
                } catch (IOException | ClassNotFoundException e) {
                    setDefaultStatus();
                    System.out.println("[ERROR] " + e.getMessage());
                }
            }
        });

        setDefaultStatus();

        checkBoxConnetction.setEnabled(false);
        checkBoxConnetction.setBackground(Color.LIGHT_GRAY);
        checkBoxLogin.setEnabled(false);
        checkBoxLogin.setBackground(Color.LIGHT_GRAY);

        tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Download", panelDownload);
        tabbedPane.addTab("Upload", panelUpload);

        fieldFileSize.setEnabled(false);

        progressBar.setPreferredSize(new Dimension(200, 30));
        progressBar.setStringPainted(true);

        //Настройка макета
        this.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(5, 5, 5, 5);

        //==================================================
        //          Добаление компонентов: подключение
        //==================================================
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        this.add(labelHost, constraints);

        constraints.gridx = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 1.0;
        constraints.gridwidth = 2;
        this.add(fieldHost, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        this.add(labelPort, constraints);

        constraints.gridx = 1;
        constraints.gridwidth = 2;
        this.add(fieldPort, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        this.add(labelClientPort, constraints);

        constraints.gridx = 1;
        constraints.gridwidth = 2;
        this.add(fieldClientPort, constraints);

        constraints.gridy = 3;
        constraints.gridwidth = 1;
        this.add(buttonConnect, constraints);

        constraints.gridx = 2;
        this.add(buttonDisconnect, constraints);

        constraints.gridx = 1;
        constraints.gridy = 4;
        constraints.gridwidth = 2;
        this.add(checkBoxConnetction, constraints);

        constraints.gridx = 0;
        constraints.gridy = 5;
        constraints.gridwidth = 1;
        this.add(labelUsername, constraints);

        constraints.gridx = 1;
        constraints.gridwidth = 2;
        this.add(fieldUsername, constraints);

        constraints.gridx = 0;
        constraints.gridy = 6;
        constraints.gridwidth = 1;
        this.add(labelPassword, constraints);

        constraints.gridx = 1;
        constraints.gridwidth = 2;
        this.add(fieldPassword, constraints);

        constraints.gridy = 7;
        this.add(checkBoxLogin, constraints);

        constraints.gridy = 8;
        constraints.gridwidth = 1;
        this.add(buttonLogin, constraints);

        constraints.gridx = 2;
        this.add(buttonLogout, constraints);

        //==================================================
        //          Добаление компонентов: скачать/загрузить
        //==================================================

        constraints.gridwidth = 3;
        constraints.gridx = 0;
        constraints.gridy = 9;
        constraints.anchor = GridBagConstraints.CENTER;
        this.add(tabbedPane, constraints);
        //this.add(panelDownload, constraints);

        //==================================================
        //          Добаление компонентов: размер файла и прогрес-бар
        //==================================================

        constraints.gridwidth = 1;
        constraints.gridx = 0;
        constraints.gridy = 10;
        constraints.anchor = GridBagConstraints.WEST;
        this.add(labelFileSize, constraints);

        constraints.gridx = 1;
        constraints.gridwidth = 2;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        this.add(fieldFileSize, constraints);

        constraints.gridx = 0;
        constraints.gridy = 11;
        constraints.gridwidth = 1;
        this.add(labelProgress, constraints);

        constraints.gridx = 1;
        constraints.gridwidth = 2;
        this.add(progressBar, constraints);

        this.pack();
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //==================================================
        //          Значения по умолчанию
        //==================================================

        setDefaultValues();
    }

    private void setFileSize(long fileSize) {
        fieldFileSize.setText(String.valueOf(fileSize));
    }

    private void setDefaultValues() {
        fieldHost.setText("127.0.0.1");
        fieldPort.setText("4000");
        fieldClientPort.setText("4041");
        fieldUsername.setText("user_01");
        //Для удобства.
        fieldPassword.setText("123");
    }

    private void setDefaultStatus() {
        buttonDisconnect.setEnabled(false);
        buttonLogin.setEnabled(false);
        buttonLogout.setEnabled(false);
        panelUpload.setEnabled(false);
        panelDownload.setEnabled(false);
    }

    private void setInterfaceEnabled(boolean val) {
        fieldHost.setEnabled(val);
        fieldPort.setEnabled(val);
        fieldUsername.setEnabled(val);
        fieldPassword.setEnabled(val);
        tabbedPane.setEnabled(val);
        panelDownload.setEnabled(val);
        panelUpload.setEnabled(val);
    }

    private String getHost() {
        return fieldHost.getText();
    }
    private int getPort() {
        int port = 0;
        if (!fieldPort.getText().equals("")) {
            port = Integer.parseInt(fieldPort.getText());
        }
        return port;
    }
    private  int getClientPort() {
        int port = 0;
        if (!fieldClientPort.getText().equals("")) {
            port = Integer.parseInt(fieldClientPort.getText());
        }
        return port;
    }
    private String getUsername() {
        return fieldUsername.getText();
    }
    private String getPassword() {
        return new String(fieldPassword.getPassword());
    }

    //==================================================
    //Обработать событие нажатия кнопки загрузки
    //==================================================
    private void buttonDownloadActionPerformed(ActionEvent event) {
        String host = fieldHost.getText();
        int port = getPort();
        String username = getUsername();
        String password = getPassword();
        String downloadPath = panelDownload.getDownloadPath();
        String saveDir = panelDownload.getDirPath();

        progressBar.setValue(0);
        try {
            ftpClient.downloadFile(
                    downloadPath,
                    saveDir,
                    progressBar
            );
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("[ERROR] " + e.getMessage());
        }
    }
    //==================================================
    //Обработать событие нажатия кнопки выгрузки
    //==================================================
    private void buttonUploadActionPerformed(ActionEvent event) {
        String host = fieldHost.getText();
        int port = getPort();
        String username = getUsername();
        String password = getPassword();
        String uploadPath = panelUpload.getUploadPath();
        String filePath = panelUpload.getFilePath();

        File uploadFile = new File(filePath);
        setFileSize(uploadFile.length());
        progressBar.setValue(0);
        try {
            ftpClient.uploadFile(
                    uploadPath,
                    filePath,
                    progressBar
            );
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("[ERROR] " + e.getMessage());
        }
    }
    //==================================================
    //Обновлять состояние индикатора выполнения всякий раз, когда изменяется ход загрузки
    //==================================================
    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if ("progress" == evt.getPropertyName()) {
            int progress = (Integer) evt.getNewValue();
            progressBar.setValue(progress);
        }
    }

    //==================================================
    //          Запуск приложения
    //==================================================
    public static void main(String[] args) {
        try {
            // set look and feel to system dependent
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ClientInterface().setVisible(true);
            }
        });
    }
}
