package Server;

import javax.xml.crypto.Data;
import java.io.*;
import java.net.InetAddress;
import java.util.Date;

import static Server.Config.*;


public class DataClient  {
    //Параметры пользователя:
    private InetAddress clientAddress = null;
    private int clientPort = 0;
    private String username = null;
    private boolean authorized = false;
    //Время последнего обращения:
    private long time;//ms
    //Загрузка или отправка файла:
    private boolean downloadFile = false;
    private boolean uploadFile = false;
    private String fileName = null;
    private File file = null;
    private FileInputStream fileInput = null;
    private FileOutputStream fileOutput = null;
    private byte[] buffer = null;
    private long numOfpackages = 0;
    private long numOfpackag = 0;
    //--------------------------------------------------
    // КОНСТРУКТОР
    //--------------------------------------------------
    public DataClient(InetAddress clientAddress, int clientPort) {
        this.clientAddress = clientAddress;
        this.clientPort = clientPort;
        time = (new Date()).getTime();
    }
    //--------------------------------------------------
    //
    //--------------------------------------------------
    public boolean isThisUser(
            InetAddress clientAddress,
            int         clientPort
    ) {
        if (this.clientAddress == clientAddress && this.clientPort == clientPort) {
            return true;
        }
        return false;
    }
    //--------------------------------------------------
    // АУТЕНТИФИКАЦИЯ
    //--------------------------------------------------
    public void login(
            Authorization   authorization,
            String          username,
            String          password
    ) {
        if (authorized) { return; }
        this.username = username;
        authorized = authorization.isExist(this.username, password);
    }
    public void  logout() {
        authorized = false;
        username = null;
    }
    //--------------------------------------------------
    // НАЧАЛО СКАЧИВАНИЯ И ОТПРАВКИ ФАЙЛА
    //--------------------------------------------------
    public byte[] startDownloadFile(
            String  fileName,
            long    numOfpackages
    ) throws IOException {
        //Если идёт загрузка или отправка файла, то:
        if (uploadFile || downloadFile) {
            return null;
        }
        this.fileName = fileName;
        this.numOfpackages = numOfpackages;

        downloadFile = true;
        numOfpackag = 1;
        file = new File(DIRECTORY_WITH_FILES + this.fileName);
        fileOutput = new FileOutputStream(file);

        return FTP_Package.toByteArray(
                new FTP_Package(
                        FTP_Package.Type.START_DOWNLOADING_FILE,
                        fileName.getBytes(),
                        0
                ));
    }
    public byte[] startUploadFile(String fileName) throws IOException {
        //Если идёт загрузка или отправка файла, то:
        if (uploadFile || downloadFile) {
            return null;
        }
        this.fileName = fileName;

        file = new File(DIRECTORY_WITH_FILES + this.fileName);
        if (file.exists()) {
            //Файл существет.
            uploadFile = true;
            fileInput = new FileInputStream(file);
            numOfpackages = (file.length() / BUFFER_SIZE) +
                    ((file.length() % BUFFER_SIZE) > 0 ? 1 : 0);
            System.out.println("[INFO:" + clientAddress + ":" + clientPort +
                    "] File size (byte): " + file.length());
        } else {
            //Файл отсутствует.
            System.out.println("[ERROR: " + clientAddress + ":" + clientPort +
                    "] The file was not found!");
            return null;
        }

        return FTP_Package.toByteArray(
                new FTP_Package(
                        FTP_Package.Type.START_UPLOADING_FILE,
                        (String.valueOf(this.numOfpackages)).getBytes(),
                        file.length()//Играет роль размера файла.
                ));
    }
    //--------------------------------------------------
    // СКАЧИВАНИЯ И ОТПРАВКИ ФАЙЛА
    //--------------------------------------------------
    public byte[] uploadFile(boolean nextPackag) throws IOException {
        //Если не идёт отправка файла, то:
        if (!(uploadFile)) {
            System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                    "] File isn't upload.");
            return null;
        }
        if (nextPackag || numOfpackag == 0) {
            numOfpackag++;
            buffer = fileInput.readNBytes(BUFFER_SIZE);
        }
        System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                "] The package was sent under the number: " +
                numOfpackag + "/" + numOfpackages);
        return FTP_Package.toByteArray(
                new FTP_Package(
                        FTP_Package.Type.FILE_UPLOAD,
                        buffer,
                        numOfpackag
                ));
    }
    public byte[] downloadFile(
            byte[] buffer,
            long numOfpackag
    ) throws IOException {
        //Если не идёт скачивание файла, то:
        if (!(downloadFile)) {
            System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                    "] File isn't upload.");
            return null;
        }

        System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                "] The package was accept under the number: " +
                numOfpackag + "/" + numOfpackages);
        if (this.numOfpackag <= numOfpackages) {
            if (this.numOfpackag != numOfpackag) {
                return FTP_Package.toByteArray(
                        new FTP_Package(
                                FTP_Package.Type.FILE_DOWNLOAD_OLD
                        ));
            } else {
                this.numOfpackag++;
                this.buffer = buffer;
                fileOutput.write(buffer);
                return FTP_Package.toByteArray(
                        new FTP_Package(
                                FTP_Package.Type.FILE_DOWNLOAD
                        ));
            }
        }

        return FTP_Package.toByteArray(
                new FTP_Package(
                        FTP_Package.Type.FILE_UPLOAD,
                        buffer,
                        numOfpackag
                ));
    }
    //--------------------------------------------------
    // КОНЕЦ СКАЧИВАНИЯ И ОТПРАВКИ ФАЙЛА
    //--------------------------------------------------
    public byte[] endLoadFile() throws IOException {
        //Если не идёт загрузка или отправка файла, то:
        if (!(uploadFile || downloadFile)) {
            System.out.println("[ACTION:" + clientAddress + ":" + clientPort +
                    "] File isn't load.");
            return null;
        }
        numOfpackages = 0;
        numOfpackag = 0;
        if (fileInput != null) {
            fileInput.close();
            fileInput = null;
        }
        if (fileOutput != null) {
            fileOutput.close();
            fileOutput = null;
        }
        file = null;
        fileName = null;
        buffer = null;
        downloadFile = false;
        uploadFile = false;

        return FTP_Package.toByteArray(
                new FTP_Package(
                        FTP_Package.Type.END_LOAD_FILE
                ));
    }
    //--------------------------------------------------
    // GET
    //--------------------------------------------------
    public InetAddress getClientAddress() {
        return clientAddress;
    }
    public int getClientPort() {
        return clientPort;
    }
    public String getUsername() {
        return username;
    }
    public boolean isAuthorized() {
        return authorized;
    }
    public boolean isDownloadFile() {
        return downloadFile;
    }
    public boolean isUploadFile() {
        return uploadFile;
    }
    public boolean isLive() {
        long currTime = (new Date()).getTime();
        if (currTime - time > TIMEOUT_DEL_DATA) {
            return false;
        }
        return true;
    }
    //--------------------------------------------------
    // SET
    //--------------------------------------------------
    public void setUsername(String username) {
        if (authorized) { return; }
        this.username = username;
    }
    public void setLive() {
        long currTime = (new Date()).getTime();
        time = currTime;
    }
}
